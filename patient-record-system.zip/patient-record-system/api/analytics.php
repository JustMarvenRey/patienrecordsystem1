<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

// Dashboard analytics — role-specific and read-only (nothing here writes to the database).
//   Admin  : clinic-wide overview (patients, visits, revenue, diagnoses, medicines, workload)
//   Doctor : ONLY the doctor's own appointments / consultations / patients
//   Staff  : front-desk + billing view (today's queue, collections, unpaid bills, no-shows)
// The role (and, for doctors, WHICH doctor) is looked up on the server from actingUserId — the
// client can't ask for another doctor's numbers. NOTE: like the rest of this app there are no
// server-side sessions, so actingUserId is sent by the client; it's a basic guard, not real auth.
class Analytics {

    private function who($conn, $actingUserId) {
        if (empty($actingUserId)) return null;
        $stmt = $conn->prepare("SELECT u.UserID, r.RoleName FROM USERS u
                                JOIN ROLE r ON u.RoleID = r.RoleID
                                WHERE u.UserID = :id AND u.Status = 'Active'");
        $stmt->bindValue(":id", $actingUserId);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    private function rows($conn, $sql, $params = []) {
        $stmt = $conn->prepare($sql);
        foreach ($params as $k => $v) $stmt->bindValue($k, $v);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function one($conn, $sql, $params = []) {
        return $this->rows($conn, $sql, $params)[0];
    }

    // Appointment numbers shared by every role. $uid limits them to one doctor (null = everyone).
    private function appointmentStats($conn, $start, $uid = null) {
        $and = $uid ? " AND UserID = :uid" : "";
        $p = [":s" => $start];
        if ($uid) $p[":uid"] = $uid;

        $r = $this->one($conn, "SELECT COUNT(*) AS total,
                                       SUM(Status = 'Completed') AS completed,
                                       SUM(Status = 'Cancelled') AS cancelled,
                                       SUM(Status = 'No-Show')   AS noshow,
                                       SUM(Status = 'Scheduled') AS scheduled,
                                       COUNT(DISTINCT PatientID) AS patients
                                FROM APPOINTMENT WHERE AppointmentDate >= :s $and", $p);

        $q = $uid ? [":uid" => $uid] : [];
        $today = $this->one($conn, "SELECT COUNT(*) AS n FROM APPOINTMENT
                                    WHERE AppointmentDate = CURDATE() AND Status <> 'Cancelled' $and", $q);
        $upcoming = $this->one($conn, "SELECT COUNT(*) AS n FROM APPOINTMENT
                                       WHERE AppointmentDate >= CURDATE() AND Status = 'Scheduled' $and", $q);
        $awaiting = $this->one($conn, "SELECT COUNT(*) AS n FROM APPOINTMENT
                                       WHERE AppointmentDate <= CURDATE() AND Status = 'Scheduled' $and", $q);

        return [
            "kpi" => [
                "appointments" => (int)$r['total'],
                "completed"    => (int)$r['completed'],
                "cancelled"    => (int)$r['cancelled'],
                "noShow"       => (int)$r['noshow'],
                "scheduled"    => (int)$r['scheduled'],
                "patientsSeen" => (int)$r['patients'],
                "today"        => (int)$today['n'],
                "upcoming"     => (int)$upcoming['n'],
                "awaiting"     => (int)$awaiting['n'],
            ],
            "apptByMonth" => $this->rows($conn,
                "SELECT DATE_FORMAT(AppointmentDate, '%Y-%m') AS ym, Status, COUNT(*) AS n
                 FROM APPOINTMENT WHERE AppointmentDate >= :s $and
                 GROUP BY ym, Status ORDER BY ym", $p),
            // WEEKDAY(): 0 = Monday ... 6 = Sunday
            "weekday" => $this->rows($conn,
                "SELECT WEEKDAY(AppointmentDate) AS d, COUNT(*) AS n
                 FROM APPOINTMENT WHERE AppointmentDate >= :s AND Status <> 'Cancelled' $and
                 GROUP BY d", $p),
        ];
    }

    private function ageBands($conn, $patientFilterSql, $params = []) {
        return $this->rows($conn,
            "SELECT CASE WHEN age < 13 THEN '0-12' WHEN age < 18 THEN '13-17'
                         WHEN age < 40 THEN '18-39' WHEN age < 60 THEN '40-59' ELSE '60+' END AS band,
                    COUNT(*) AS n
             FROM (SELECT TIMESTAMPDIFF(YEAR, p.DateOfBirth, CURDATE()) AS age
                   FROM PATIENT p WHERE $patientFilterSql) t
             GROUP BY band", $params);
    }

    // ── Admin ──────────────────────────────────────────────────────────
    private function adminData($conn, $start) {
        $d = $this->appointmentStats($conn, $start);
        $k = $d['kpi'];

        $k['activePatients'] = (int)$conn->query("SELECT COUNT(*) FROM PATIENT WHERE Status = 'Active'")->fetchColumn();
        $k['activeDoctors']  = (int)$conn->query("SELECT COUNT(*) FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                                                  WHERE r.RoleName = 'Doctor' AND u.Status = 'Active'")->fetchColumn();
        $k['consultations']  = (int)$this->one($conn, "SELECT COUNT(*) AS n FROM CONSULTATION
                                                       WHERE Status = 'Active' AND ConsultationDate >= :s", [":s" => $start])['n'];
        $b = $this->one($conn, "SELECT COALESCE(SUM(CASE WHEN Status = 'Paid'    THEN TotalAmount END), 0) AS paid,
                                       COALESCE(SUM(CASE WHEN Status = 'Pending' THEN TotalAmount END), 0) AS pending,
                                       SUM(Status = 'Pending') AS pendingCount
                                FROM BILLING WHERE BillDate >= :s", [":s" => $start]);
        $k['revenuePaid']    = (float)$b['paid'];
        $k['revenuePending'] = (float)$b['pending'];
        $k['pendingCount']   = (int)$b['pendingCount'];
        $d['kpi'] = $k;

        $d['revenueByMonth'] = $this->rows($conn,
            "SELECT DATE_FORMAT(BillDate, '%Y-%m') AS ym, Status, SUM(TotalAmount) AS total
             FROM BILLING WHERE BillDate >= :s AND Status IN ('Paid','Pending')
             GROUP BY ym, Status ORDER BY ym", [":s" => $start]);

        $d['topDiagnoses'] = $this->rows($conn,
            "SELECT d.ICD10Code, d.DiagnosisName, COUNT(*) AS n
             FROM CONSULTATION_DIAGNOSIS cd
             JOIN CONSULTATION c    ON cd.ConsultationID = c.ConsultationID
             JOIN DIAGNOSIS_ICD10 d ON cd.DiagnosisID    = d.DiagnosisID
             WHERE cd.Status = 'Active' AND c.Status = 'Active' AND c.ConsultationDate >= :s
             GROUP BY d.DiagnosisID, d.ICD10Code, d.DiagnosisName
             ORDER BY n DESC, d.DiagnosisName LIMIT 8", [":s" => $start]);

        $d['topMedicines'] = $this->rows($conn,
            "SELECT m.MedicineName, COUNT(*) AS n
             FROM PRESCRIPTION pr
             JOIN CONSULTATION c ON pr.ConsultationID = c.ConsultationID
             JOIN MEDICINE m     ON pr.MedicineID     = m.MedicineID
             WHERE pr.Status = 'Active' AND c.Status = 'Active' AND c.ConsultationDate >= :s
             GROUP BY m.MedicineID, m.MedicineName
             ORDER BY n DESC, m.MedicineName LIMIT 8", [":s" => $start]);

        $d['perDoctor'] = $this->perDoctor($conn, $start);
        $d['gender'] = $this->rows($conn, "SELECT Gender, COUNT(*) AS n FROM PATIENT WHERE Status = 'Active' GROUP BY Gender ORDER BY n DESC");
        $d['ages']   = $this->ageBands($conn, "p.Status = 'Active'");
        return $d;
    }

    private function perDoctor($conn, $start) {
        return $this->rows($conn,
            "SELECT CONCAT('Dr. ', u.LastName) AS DoctorName,
                    COUNT(a.AppointmentID)  AS appointments,
                    COUNT(c.ConsultationID) AS consultations
             FROM APPOINTMENT a
             JOIN USERS u ON a.UserID = u.UserID
             LEFT JOIN CONSULTATION c ON c.AppointmentID = a.AppointmentID AND c.Status = 'Active'
             WHERE a.AppointmentDate >= :s AND a.Status <> 'Cancelled'
             GROUP BY u.UserID, u.LastName
             ORDER BY appointments DESC, u.LastName LIMIT 8", [":s" => $start]);
    }

    // ── Doctor: strictly this doctor's own records ─────────────────────
    private function doctorData($conn, $start, $uid) {
        $d = $this->appointmentStats($conn, $start, $uid);
        $p = [":s" => $start, ":uid" => $uid];

        $c = $this->one($conn,
            "SELECT COUNT(*) AS n, COUNT(DISTINCT a.PatientID) AS patients
             FROM CONSULTATION c JOIN APPOINTMENT a ON c.AppointmentID = a.AppointmentID
             WHERE c.Status = 'Active' AND c.ConsultationDate >= :s AND a.UserID = :uid", $p);
        $d['kpi']['consultations'] = (int)$c['n'];
        $d['kpi']['patientsSeen']  = (int)$c['patients'];

        $d['topDiagnoses'] = $this->rows($conn,
            "SELECT d.ICD10Code, d.DiagnosisName, COUNT(*) AS n
             FROM CONSULTATION_DIAGNOSIS cd
             JOIN CONSULTATION c    ON cd.ConsultationID = c.ConsultationID
             JOIN APPOINTMENT a     ON c.AppointmentID   = a.AppointmentID
             JOIN DIAGNOSIS_ICD10 d ON cd.DiagnosisID    = d.DiagnosisID
             WHERE cd.Status = 'Active' AND c.Status = 'Active' AND c.ConsultationDate >= :s AND a.UserID = :uid
             GROUP BY d.DiagnosisID, d.ICD10Code, d.DiagnosisName
             ORDER BY n DESC, d.DiagnosisName LIMIT 8", $p);

        $d['topMedicines'] = $this->rows($conn,
            "SELECT m.MedicineName, COUNT(*) AS n
             FROM PRESCRIPTION pr
             JOIN CONSULTATION c ON pr.ConsultationID = c.ConsultationID
             JOIN APPOINTMENT a  ON c.AppointmentID   = a.AppointmentID
             JOIN MEDICINE m     ON pr.MedicineID     = m.MedicineID
             WHERE pr.Status = 'Active' AND c.Status = 'Active' AND c.ConsultationDate >= :s AND a.UserID = :uid
             GROUP BY m.MedicineID, m.MedicineName
             ORDER BY n DESC, m.MedicineName LIMIT 8", $p);

        // Age mix of the patients this doctor has appointments with in the period
        $d['ages'] = $this->ageBands($conn,
            "p.PatientID IN (SELECT a.PatientID FROM APPOINTMENT a
                              WHERE a.UserID = :uid AND a.AppointmentDate >= :s AND a.Status <> 'Cancelled')", $p);
        return $d;
    }

    // ── Staff: front desk + billing ────────────────────────────────────
    private function staffData($conn, $start) {
        $d = $this->appointmentStats($conn, $start);
        $p = [":s" => $start];

        $b = $this->one($conn,
            "SELECT COALESCE(SUM(CASE WHEN Status = 'Paid' AND BillDate >= :s THEN TotalAmount END), 0) AS collected,
                    SUM(Status = 'Paid'      AND BillDate >= :s2) AS paidCount,
                    COALESCE(SUM(CASE WHEN Status = 'Pending' THEN TotalAmount END), 0) AS pending,
                    SUM(Status = 'Pending') AS pendingCount
             FROM BILLING", [":s" => $start, ":s2" => $start]);
        $d['kpi']['collected']    = (float)$b['collected'];
        $d['kpi']['paidCount']    = (int)$b['paidCount'];
        $d['kpi']['pending']      = (float)$b['pending'];      // all-time: money still owed
        $d['kpi']['pendingCount'] = (int)$b['pendingCount'];

        // Active consultations that don't have a bill yet — work waiting for the front desk
        $d['kpi']['unbilled'] = (int)$conn->query(
            "SELECT COUNT(*) FROM CONSULTATION c LEFT JOIN BILLING b ON b.ConsultationID = c.ConsultationID
             WHERE c.Status = 'Active' AND b.BillID IS NULL")->fetchColumn();

        $d['collectionsByMonth'] = $this->rows($conn,
            "SELECT DATE_FORMAT(BillDate, '%Y-%m') AS ym, Status, SUM(TotalAmount) AS total
             FROM BILLING WHERE BillDate >= :s AND Status IN ('Paid','Pending')
             GROUP BY ym, Status ORDER BY ym", $p);

        $d['billStatus'] = $this->rows($conn,
            "SELECT Status, COUNT(*) AS n FROM BILLING WHERE BillDate >= :s GROUP BY Status", $p);

        // How long unpaid bills have been waiting (all pending bills, regardless of range)
        $d['pendingAging'] = $this->rows($conn,
            "SELECT CASE WHEN days <= 7 THEN '0-7 days' WHEN days <= 30 THEN '8-30 days' ELSE '31+ days' END AS band,
                    COUNT(*) AS n, SUM(TotalAmount) AS total
             FROM (SELECT DATEDIFF(CURDATE(), BillDate) AS days, TotalAmount FROM BILLING WHERE Status = 'Pending') t
             GROUP BY band");

        $d['perDoctor'] = $this->perDoctor($conn, $start);
        return $d;
    }

    // months = 3 | 6 | 12 | 0 (0 = all time). The range starts on the 1st of the earliest month.
    function getDashboardAnalytics($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true) ?: [];
        $me = $this->who($conn, $json['actingUserId'] ?? null);
        if (!$me) return json_encode(["error" => "forbidden"]);

        $months = (int)($json['months'] ?? 6);
        if (!in_array($months, [0, 3, 6, 12], true)) $months = 6;
        $start = $months === 0
            ? "1900-01-01"
            : (new DateTime("first day of this month"))->modify("-" . ($months - 1) . " months")->format("Y-m-d");

        switch ($me['RoleName']) {
            case "Admin":  $data = $this->adminData($conn, $start); break;
            case "Doctor": $data = $this->doctorData($conn, $start, (int)$me['UserID']); break;
            case "Staff":  $data = $this->staffData($conn, $start); break;
            default:       return json_encode(["error" => "forbidden"]);
        }
        $data['role']   = $me['RoleName'];
        $data['months'] = $months;
        $data['start']  = $months === 0 ? null : $start;
        return json_encode($data);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? "";
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? "";
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$analytics = new Analytics();
switch ($operation) {
    case "getDashboardAnalytics": echo $analytics->getDashboardAnalytics($json); break;
}
?>
