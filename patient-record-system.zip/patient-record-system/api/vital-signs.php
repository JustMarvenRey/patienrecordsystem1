<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";

class VitalSign {

    // Role name of an ACTIVE user, or null (same approach as billing.php —
    // the app has no server-side sessions, so actingUserId comes from the client).
    private function roleOf($conn, $actingUserId) {
        if (empty($actingUserId)) return null;
        $stmt = $conn->prepare("SELECT r.RoleName FROM USERS u
                                JOIN ROLE r ON u.RoleID = r.RoleID
                                WHERE u.UserID = :id AND u.Status = 'Active'");
        $stmt->bindParam(":id", $actingUserId);
        $stmt->execute();
        $role = $stmt->fetchColumn();
        return $role === false ? null : $role;
    }

    // Vital signs are taken by Staff only (Doctors / Admin can view them).
    private function isStaff($conn, $actingUserId) {
        return $this->roleOf($conn, $actingUserId) === "Staff";
    }

    // Vital sign for the appointment behind a consultation (empty array if none).
    function getVitalSign($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT v.* FROM VITAL_SIGN v
                JOIN CONSULTATION c
                  ON (v.AppointmentID = c.AppointmentID OR v.ConsultationID = c.ConsultationID)
                WHERE c.ConsultationID = :consultationId AND v.Status = 'Active'
                LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":consultationId", $json['consultationId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Vital sign recorded for an appointment (empty array if none yet).
    function getVitalSignByAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $stmt = $conn->prepare("SELECT * FROM VITAL_SIGN
                                WHERE AppointmentID = :appointmentId AND Status = 'Active'");
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Staff records vital signs for an appointment. One record per appointment.
    function insertVitalSign($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        if (!$this->isStaff($conn, $json['actingUserId'] ?? null)) {
            return json_encode(["error" => "forbidden"]);
        }

                list($err, $json) = Validator::run("vitals", $json);
        if ($err) return Validator::fail($err);
        if (count(array_filter(array_intersect_key($json, array_flip(['temperature','bloodPressure','heartRate','respiratoryRate','oxygenSaturation','weight','height'])), function ($x) { return $x !== null && $x !== ''; })) === 0)
            return Validator::fail("Enter at least one vital sign.");
$appointmentId = $json['appointmentId'] ?? null;
        if (empty($appointmentId)) return json_encode(["error" => "missing_fields"]);

        $ap = $conn->prepare("SELECT Status FROM APPOINTMENT WHERE AppointmentID = :id");
        $ap->bindParam(":id", $appointmentId);
        $ap->execute();
        $apStatus = $ap->fetchColumn();
        if ($apStatus === false) return json_encode(["error" => "not_found"]);
        if ($apStatus === 'Cancelled') return json_encode(["error" => "appointment_cancelled"]);

        // Link to the consultation too, if the doctor already created one
        $cs = $conn->prepare("SELECT ConsultationID FROM CONSULTATION WHERE AppointmentID = :id");
        $cs->bindParam(":id", $appointmentId);
        $cs->execute();
        $consultationId = $cs->fetchColumn();
        if ($consultationId === false) $consultationId = null;

        $chk = $conn->prepare("SELECT VitalSignID, Status FROM VITAL_SIGN WHERE AppointmentID = :id");
        $chk->bindParam(":id", $appointmentId);
        $chk->execute();
        $existing = $chk->fetch(PDO::FETCH_ASSOC);
        if ($existing && $existing['Status'] === 'Active') {
            return json_encode(["error" => "already_has_vital_sign"]);
        }

        if ($existing) {
            // A soft-deleted record exists: reuse it instead of violating UNIQUE
            $sql = "UPDATE VITAL_SIGN SET
                        ConsultationID = :consultationId, Temperature = :temperature,
                        BloodPressure = :bloodPressure, HeartRate = :heartRate,
                        RespiratoryRate = :respiratoryRate, OxygenSaturation = :oxygenSaturation,
                        Weight = :weight, Height = :height, Status = 'Active'
                    WHERE VitalSignID = :vitalSignId";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(":vitalSignId", $existing['VitalSignID']);
        } else {
            $sql = "INSERT INTO VITAL_SIGN
                        (AppointmentID, ConsultationID, Temperature, BloodPressure, HeartRate,
                         RespiratoryRate, OxygenSaturation, Weight, Height, Status)
                    VALUES
                        (:appointmentId, :consultationId, :temperature, :bloodPressure, :heartRate,
                         :respiratoryRate, :oxygenSaturation, :weight, :height, 'Active')";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(":appointmentId", $appointmentId);
        }
        $stmt->bindValue(":consultationId",   $consultationId);
        $stmt->bindValue(":temperature",      $json['temperature']      ?? null);
        $stmt->bindValue(":bloodPressure",    $json['bloodPressure']    ?? null);
        $stmt->bindValue(":heartRate",        $json['heartRate']        ?? null);
        $stmt->bindValue(":respiratoryRate",  $json['respiratoryRate']  ?? null);
        $stmt->bindValue(":oxygenSaturation", $json['oxygenSaturation'] ?? null);
        $stmt->bindValue(":weight",           $json['weight']           ?? null);
        $stmt->bindValue(":height",           $json['height']           ?? null);
        $stmt->execute();

        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Staff updates an existing vital sign record.
    function updateVitalSign($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        if (!$this->isStaff($conn, $json['actingUserId'] ?? null)) {
            return json_encode(["error" => "forbidden"]);
        }

                if ($e = Validator::badId($json, ['vitalSignId'])) return Validator::fail($e);
        list($err, $json) = Validator::run("vitals", $json);
        if ($err) return Validator::fail($err);
        if (count(array_filter(array_intersect_key($json, array_flip(['temperature','bloodPressure','heartRate','respiratoryRate','oxygenSaturation','weight','height'])), function ($x) { return $x !== null && $x !== ''; })) === 0)
            return Validator::fail("Enter at least one vital sign.");
$sql = "UPDATE VITAL_SIGN SET
                    Temperature       = :temperature,
                    BloodPressure     = :bloodPressure,
                    HeartRate         = :heartRate,
                    RespiratoryRate   = :respiratoryRate,
                    OxygenSaturation  = :oxygenSaturation,
                    Weight            = :weight,
                    Height            = :height
                WHERE VitalSignID = :vitalSignId";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(":temperature",      $json['temperature']      ?? null);
        $stmt->bindValue(":bloodPressure",    $json['bloodPressure']    ?? null);
        $stmt->bindValue(":heartRate",        $json['heartRate']        ?? null);
        $stmt->bindValue(":respiratoryRate",  $json['respiratoryRate']  ?? null);
        $stmt->bindValue(":oxygenSaturation", $json['oxygenSaturation'] ?? null);
        $stmt->bindValue(":weight",           $json['weight']           ?? null);
        $stmt->bindValue(":height",           $json['height']           ?? null);
        $stmt->bindParam(":vitalSignId",      $json['vitalSignId']);
        $stmt->execute();

        // rowCount is 0 when nothing changed - treat a re-save of identical values as success
        return json_encode(1);
    }

    // Soft delete — sets Status to Inactive (Staff only)
    function deleteVitalSign($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->isStaff($conn, $json['actingUserId'] ?? null)) {
            return json_encode(["error" => "forbidden"]);
        }
        $sql = "UPDATE VITAL_SIGN SET Status = 'Inactive'
                WHERE VitalSignID = :vitalSignId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":vitalSignId", $json['vitalSignId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }
}

// submitted by the client - operation and json
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$vitalSign = new VitalSign();
switch ($operation) {
    case "getVitalSign":
        echo $vitalSign->getVitalSign($json);
        break;
    case "getVitalSignByAppointment":
        echo $vitalSign->getVitalSignByAppointment($json);
        break;
    case "insertVitalSign":
        echo $vitalSign->insertVitalSign($json);
        break;
    case "updateVitalSign":
        echo $vitalSign->updateVitalSign($json);
        break;
    case "deleteVitalSign":
        echo $vitalSign->deleteVitalSign($json);
        break;
}
?>
