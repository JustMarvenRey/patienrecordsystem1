<?php
// Update these to match your local MySQL setup (e.g. XAMPP defaults shown below)
$host = "localhost";
$db   = "patient_record_system";
$user = "root";
$pass = "";

date_default_timezone_set('Asia/Manila');   // match the browser/clinic time (PHP defaults to UTC on many setups)

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("SET time_zone = '+08:00'");   // so NOW()/CURDATE() also use Philippine time
    // Adds any new columns this version needs to an older database (no data is removed)
    require_once __DIR__ . "/auto-migrate.php";
    ensureSchema($conn);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $e->getMessage()]);
    exit;
}
?>
