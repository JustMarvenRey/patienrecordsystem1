<?php
// Shared server-side input validation. GENERATED from the same rule set as js/validators.js,
// so the browser and the API always agree. Every write endpoint calls:
//
//     list($err, $json) = Validator::run("patient", $json);
//     if ($err) return Validator::fail($err);
//
// run() trims text, normalises values (ICD-10 upper-case, ids -> int) and returns the
// FIRST problem as a human-readable message. Keys that aren't in the schema (actingUserId,
// patientId, ...) pass through untouched.
if (!class_exists('Validator')) {
class Validator {
    private static function schemas() {
        static $s = null;
        if ($s === null) $s = json_decode(<<<'JSON'
{
 "patient": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "dob": {
   "l": "Date of birth",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 1900
  },
  "gender": {
   "l": "Gender",
   "t": "enum",
   "r": 1,
   "vals": [
    "Male",
    "Female",
    "Other"
   ]
  },
  "genderDetails": {
   "l": "Gender details",
   "t": "text",
   "max": 100,
   "reqIf": [
    "gender",
    "Other"
   ]
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "address": {
   "l": "Address",
   "t": "text",
   "max": 255
  }
 },
 "user_insert": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "username": {
   "l": "Username",
   "t": "username",
   "startLetter": 1,
   "r": 1
  },
  "password": {
   "l": "Password",
   "t": "password",
   "mix": 1,
   "notSameAs": "username",
   "r": 1
  },
  "roleId": {
   "l": "Role",
   "t": "id",
   "r": 1
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "specializationIds": {
   "l": "Specializations",
   "t": "ids"
  }
 },
 "user_update": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "username": {
   "l": "Username",
   "t": "username",
   "startLetter": 1,
   "r": 1
  },
  "password": {
   "l": "Password",
   "t": "password",
   "mix": 1,
   "notSameAs": "username"
  },
  "roleId": {
   "l": "Role",
   "t": "id",
   "r": 1
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "specializationIds": {
   "l": "Specializations",
   "t": "ids"
  }
 },
 "login": {
  "username": {
   "l": "Username",
   "t": "text",
   "r": 1,
   "max": 50
  },
  "password": {
   "l": "Password",
   "t": "rawtext",
   "r": 1,
   "max": 255
  }
 },
 "role": {
  "roleName": {
   "l": "Role name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 50,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 255
  }
 },
 "specialization": {
  "name": {
   "l": "Specialization name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 100,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "generic": {
  "genericName": {
   "l": "Generic name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 150,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "medicine": {
  "medicineName": {
   "l": "Medicine name",
   "t": "medname",
   "r": 1,
   "min": 2,
   "max": 150
  },
  "genericId": {
   "l": "Generic",
   "t": "id"
  },
  "dosageForm": {
   "l": "Dosage form",
   "t": "enum",
   "r": 1,
   "vals": [
    "Tablet",
    "Capsule",
    "Syrup",
    "Suspension",
    "Injection",
    "Inhaler",
    "Ointment",
    "Cream",
    "Drops",
    "Other"
   ]
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "diagnosis": {
  "icd10Code": {
   "l": "ICD-10 code",
   "t": "icd10",
   "r": 1
  },
  "name": {
   "l": "Diagnosis name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 200,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "labtest": {
  "testName": {
   "l": "Test name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 150,
   "letters": 1
  },
  "normalRange": {
   "l": "Normal range",
   "t": "title",
   "max": 100
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "appointment": {
  "patientId": {
   "l": "Patient",
   "t": "id",
   "r": 1
  },
  "userId": {
   "l": "Doctor",
   "t": "id",
   "r": 1
  },
  "appointmentDate": {
   "l": "Appointment date",
   "t": "date",
   "r": 1,
   "np": 1
  },
  "appointmentTime": {
   "l": "Appointment time",
   "t": "time",
   "r": 1
  },
  "reason": {
   "l": "Reason",
   "t": "text",
   "max": 255
  },
  "notes": {
   "l": "Notes",
   "t": "text",
   "max": 1000
  },
  "status": {
   "l": "Status",
   "t": "enum",
   "vals": [
    "Scheduled",
    "Completed",
    "Cancelled",
    "No-Show"
   ]
  }
 },
 "intake": {
  "reason": {
   "l": "Reason for visit",
   "t": "text",
   "max": 255
  },
  "chiefComplaint": {
   "l": "Chief complaint",
   "t": "text",
   "r": 1,
   "max": 1000
  },
  "symptoms": {
   "l": "Symptoms",
   "t": "text",
   "max": 1000
  }
 },
 "vitals": {
  "temperature": {
   "l": "Temperature",
   "t": "num",
   "min": 30,
   "max": 45,
   "dp": 1,
   "unit": "°C"
  },
  "bloodPressure": {
   "l": "Blood pressure",
   "t": "bp"
  },
  "heartRate": {
   "l": "Heart rate",
   "t": "int",
   "min": 20,
   "max": 300,
   "unit": "bpm"
  },
  "respiratoryRate": {
   "l": "Respiratory rate",
   "t": "int",
   "min": 4,
   "max": 80,
   "unit": "breaths/min"
  },
  "oxygenSaturation": {
   "l": "O₂ saturation",
   "t": "int",
   "min": 50,
   "max": 100,
   "unit": "%"
  },
  "weight": {
   "l": "Weight",
   "t": "num",
   "min": 0.5,
   "max": 500,
   "dp": 2,
   "unit": "kg"
  },
  "height": {
   "l": "Height",
   "t": "num",
   "min": 20,
   "max": 300,
   "dp": 1,
   "unit": "cm"
  }
 },
 "consultation": {
  "consultationDate": {
   "l": "Consultation date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "treatment": {
   "l": "Treatment",
   "t": "text",
   "max": 2000
  },
  "notes": {
   "l": "Notes",
   "t": "text",
   "max": 2000
  }
 },
 "prescription": {
  "medicineId": {
   "l": "Medicine",
   "t": "id",
   "r": 1
  },
  "prescriptionDate": {
   "l": "Prescription date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "dosage": {
   "l": "Dosage",
   "t": "text",
   "max": 100
  },
  "frequency": {
   "l": "Frequency",
   "t": "text",
   "max": 100
  },
  "duration": {
   "l": "Duration",
   "t": "text",
   "max": 100
  },
  "instructions": {
   "l": "Instructions",
   "t": "text",
   "max": 1000
  }
 },
 "lab": {
  "testId": {
   "l": "Laboratory test",
   "t": "id",
   "r": 1
  },
  "testDate": {
   "l": "Test date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "result": {
   "l": "Result",
   "t": "text",
   "max": 2000
  },
  "referenceRange": {
   "l": "Reference range",
   "t": "text",
   "max": 100
  }
 },
 "bill": {
  "consultationId": {
   "l": "Consultation",
   "t": "id",
   "r": 1
  },
  "billDate": {
   "l": "Bill date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "status": {
   "l": "Status",
   "t": "enum",
   "vals": [
    "Pending",
    "Paid",
    "Cancelled"
   ]
  }
 },
 "fee": {
  "userId": {
   "l": "Doctor",
   "t": "id",
   "r": 1
  },
  "feeAmount": {
   "l": "Fee amount",
   "t": "money",
   "r": 1,
   "min": 0.01,
   "max": 99999999.99
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 255
  }
 },
 "doctor_update": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "username": {
   "l": "Username",
   "t": "username",
   "r": 1
  },
  "password": {
   "l": "Password",
   "t": "password"
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "specializationIds": {
   "l": "Specializations",
   "t": "ids"
  }
 },
 "bill_update": {
  "billDate": {
   "l": "Bill date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "status": {
   "l": "Status",
   "t": "enum",
   "vals": [
    "Pending",
    "Paid",
    "Cancelled"
   ]
  }
 }
}
JSON
, true);
        return $s;
    }

    static function today() {
        $tz = new DateTimeZone('Asia/Manila');
        return (new DateTime('now', $tz))->format('Y-m-d');
    }

    // Booking for TODAY at a time that has already passed is not allowed.
    static function timePassedToday($date, $time) {
        if (!$date || !$time) return null;
        $now = new DateTime('now', new DateTimeZone('Asia/Manila'));
        if ($date === $now->format('Y-m-d') && substr($time, 0, 5) < $now->format('H:i')) {
            return "That time has already passed today. Please choose a later time.";
        }
        return null;
    }

    // Character count that works even when the mbstring extension is off.
    private static function len($s) {
        return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : (int)preg_match_all('/./us', $s);
    }

    // True when $table.$col already holds $value (case/space-insensitive), optionally ignoring one row.
    // $table / $col / $idCol must be hard-coded names from the calling API, never user input.
    static function exists($conn, $table, $col, $value, $idCol = null, $excludeId = null) {
        $sql = "SELECT COUNT(*) FROM $table WHERE LOWER(TRIM($col)) = LOWER(TRIM(:v))";
        if ($idCol !== null && $excludeId !== null) $sql .= " AND $idCol != :id";
        $st = $conn->prepare($sql);
        $st->bindValue(":v", $value);
        if ($idCol !== null && $excludeId !== null) $st->bindValue(":id", $excludeId);
        $st->execute();
        return (int)$st->fetchColumn() > 0;
    }

    // True when every id in $ids exists in $table.$idCol (names are hard-coded by the caller).
    static function allExist($conn, $table, $idCol, $ids) {
        $ids = array_values(array_unique(array_map('intval', (array)$ids)));
        if (!$ids) return true;
        $in = implode(',', $ids);
        return (int)$conn->query("SELECT COUNT(*) FROM $table WHERE $idCol IN ($in)")->fetchColumn() === count($ids);
    }

    // Returns an error message when any listed key is not a positive integer id, else null.
    static function badId($data, $keys) {
        foreach ((array)$keys as $k) {
            $v = is_array($data) ? ($data[$k] ?? null) : null;
            if (is_array($v) || !preg_match('/^[0-9]+$/', (string)$v) || (int)$v < 1) return "That record is not valid. Please refresh the page and try again.";
        }
        return null;
    }

    // Result of an UPDATE: MySQL reports 0 affected rows when nothing actually changed, which is
    // still a successful save. Only report "no longer exists" when the row is really gone.
    static function saved($conn, $stmt, $table, $idCol, $id) {
        if ($stmt->rowCount() > 0) return json_encode(1);
        $c = $conn->prepare("SELECT COUNT(*) FROM $table WHERE $idCol = :i");
        $c->bindValue(":i", $id); $c->execute();
        return (int)$c->fetchColumn() > 0 ? json_encode(1) : self::fail("That record no longer exists. Please refresh the page.");
    }

    static function fail($message) {
        return json_encode(["error" => "validation", "message" => $message]);
    }

    // opts: ['relax' => ['notPast']]  skips the "not in the past" rule (e.g. editing an old appointment)
    static function run($schemaName, $data, $opts = []) {
        $schema = self::schemas()[$schemaName] ?? [];
        if (!is_array($data)) $data = [];
        $relax = $opts['relax'] ?? [];
        foreach ($schema as $field => $def) {
            $raw = array_key_exists($field, $data) ? $data[$field] : null;
            list($err, $val) = self::field($def, $raw, $data, $relax);
            if ($err) return [$err, $data];
            if (!empty($opts['nullEmpty']) && $val === '') $val = null;   // store NULL instead of ''
            $data[$field] = $val;
        }
        return [null, $data];
    }

    private static function isEmpty($v) {
        return $v === null || (is_string($v) && trim($v) === '') || (is_array($v) && count($v) === 0);
    }

    private static function range($def, $n, $unit = '') {
        $u = $unit !== '' ? " $unit" : '';
        if (isset($def['min']) && isset($def['max'])) return "between {$def['min']} and {$def['max']}$u";
        if (isset($def['min'])) return "at least {$def['min']}$u";
        return "at most {$def['max']}$u";
    }

    static function field($def, $raw, $data = [], $relax = []) {
        $l = $def['l']; $t = $def['t'];
        $required = !empty($def['r']);
        if (!$required && isset($def['reqIf'])) {
            $other = $data[$def['reqIf'][0]] ?? null;
            $required = is_string($other) && $other === $def['reqIf'][1];
        }

        if (is_array($raw) && $t !== 'ids') return ["$l is not valid.", $raw];
        if ($t === 'ids') {
            if ($raw === null || $raw === '') $raw = [];
            if (!is_array($raw)) return ["$l is not valid.", $raw];
            $out = [];
            foreach ($raw as $x) {
                if (!is_scalar($x) || !preg_match('/^[0-9]+$/', (string)$x) || (int)$x < 1) return ["$l contains an item that is not valid.", $raw];
                $out[(int)$x] = (int)$x;
            }
            if (count($out) > 100) return ["$l has too many items selected.", $raw];
            if ($required && !$out) return ["$l is required.", $raw];
            return [null, array_values($out)];
        }

        $v = $raw === null ? '' : (is_string($raw) ? $raw : (string)$raw);
        if ($t !== 'password' && $t !== 'rawtext') $v = trim($v);

        if ($v === '') {
            if ($required) return ["$l is required.", $raw];
            return [null, in_array($t, ['text','name','medname','title','rawtext','password'], true) ? '' : null];
        }

        switch ($t) {
            case 'name':
                $max = $def['max'] ?? 100;
                if (self::len($v) > $max) return ["$l must be $max characters or fewer.", $v];
                if (!empty($def['min']) && self::len($v) < $def['min']) return ["$l must be at least {$def['min']} characters.", $v];
                if (!preg_match("/^\\p{L}[\\p{L}\\p{M} .'\\-]*$/u", $v)) return ["$l must contain only letters, spaces, apostrophes, periods and hyphens.", $v];
                $v = preg_replace('/\\s+/u', ' ', $v);
                return [null, $v];

            case 'medname': {
                $max = $def['max'] ?? 150; $min = $def['min'] ?? 2;
                if (self::len($v) > $max) return ["$l must be $max characters or fewer.", $v];
                if (self::len($v) < $min) return ["$l must be at least $min characters.", $v];
                if (!preg_match("/^\\p{L}[\\p{L}\\p{M} .'\\-()\\/&,]*$/u", $v)) return ["$l must contain letters only - no numbers. Spaces and . ' - ( ) / & , are allowed.", $v];
                $v = preg_replace('/\\s+/u', ' ', $v);
                return [null, $v];
            }

            case 'title':
            case 'text':
            case 'rawtext':
                $max = $def['max'] ?? 255; $min = $def['min'] ?? 0;
                if (self::len($v) > $max) return ["$l must be $max characters or fewer.", $v];
                if ($min && self::len($v) < $min) return ["$l must be at least $min characters.", $v];
                if ($t === 'rawtext') return [null, $v];
                if (preg_match('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]/', $v)) return ["$l must not contain control characters.", $v];
                if (preg_match('/<\\s*\\/?\\s*[a-zA-Z!]/', $v)) return ["$l must not contain HTML tags.", $v];
                if ($t === 'title' && !preg_match('/[\\p{L}\\p{N}]/u', $v)) return ["$l must contain at least one letter or number.", $v];
                if (!empty($def['letters']) && !preg_match('/\\p{L}/u', $v)) return ["$l must contain at least one letter (it cannot be numbers only).", $v];
                return [null, $v];

            case 'phone':
                if (!preg_match('/^[0-9]{7,15}$/', $v)) return ["$l must be 7 to 15 digits only (no spaces, +, - or letters).", $v];
                return [null, $v];

            case 'username':
                if (!preg_match('/^[A-Za-z0-9_]{3,50}$/', $v)) return ["$l must be 3 to 50 characters: letters, numbers and underscores only.", $v];
                if (!empty($def['startLetter']) && !preg_match('/^[A-Za-z]/', $v)) return ["$l must start with a letter.", $v];
                return [null, $v];

            case 'password':
                if (strlen($v) < 6) return ["$l must be at least 6 characters.", $v];
                if (strlen($v) > 72) return ["$l must be 72 characters or fewer.", $v];
                if (trim($v) === '') return ["$l must not be only spaces.", $v];
                if (!empty($def['mix']) && !(preg_match('/[A-Za-z]/', $v) && preg_match('/[0-9]/', $v))) return ["$l must include at least one letter and one number.", $v];
                if (!empty($def['notSameAs'])) {
                    $other = trim((string)($data[$def['notSameAs']] ?? ''));
                    if ($other !== '' && strcasecmp($v, $other) === 0) return ["$l must not be the same as the username.", $v];
                }
                return [null, $v];

            case 'id':
                if (!preg_match('/^[0-9]+$/', $v) || (int)$v < 1) return ["$l is not valid. Please select one.", $v];
                return [null, (int)$v];

            case 'enum':
                if (!in_array($v, $def['vals'], true)) return ["$l must be one of: " . implode(', ', $def['vals']) . ".", $v];
                return [null, $v];

            case 'date': {
                $d = DateTime::createFromFormat('Y-m-d', $v);
                $errs = DateTime::getLastErrors();
                if (!$d || $d->format('Y-m-d') !== $v || ($errs && ($errs['warning_count'] || $errs['error_count']))) return ["$l must be a real date (YYYY-MM-DD).", $v];
                if (!empty($def['my']) && (int)$d->format('Y') < $def['my']) return ["$l must not be earlier than the year {$def['my']}.", $v];
                $today = self::today();
                if (!empty($def['nf']) && $v > $today) return ["$l must not be in the future.", $v];
                if (!empty($def['np']) && !in_array('notPast', $relax, true) && $v < $today) return ["$l must not be in the past.", $v];
                return [null, $v];
            }

            case 'time':
                if (!preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/', $v)) return ["$l must be a valid time (HH:MM).", $v];
                return [null, substr($v, 0, 5)];

            case 'int': {
                if (!preg_match('/^-?[0-9]+$/', $v)) return ["$l must be a whole number.", $v];
                $n = (int)$v;
                if ((isset($def['min']) && $n < $def['min']) || (isset($def['max']) && $n > $def['max'])) return ["$l must be " . self::range($def, $n, $def['unit'] ?? '') . ".", $v];
                return [null, $n];
            }

            case 'num':
            case 'money': {
                $dp = $def['dp'] ?? ($t === 'money' ? 2 : 2);
                if (!preg_match('/^-?[0-9]+(\\.[0-9]+)?$/', $v)) return ["$l must be a valid number.", $v];
                $frac = strpos($v, '.') !== false ? strlen(substr($v, strpos($v, '.') + 1)) : 0;
                if ($frac > $dp) return ["$l must have at most $dp decimal place" . ($dp == 1 ? '' : 's') . ".", $v];
                $n = (float)$v;
                if ((isset($def['min']) && $n < $def['min']) || (isset($def['max']) && $n > $def['max'])) return ["$l must be " . self::range($def, $n, $def['unit'] ?? '') . ".", $v];
                return [null, $v];
            }

            case 'icd10': {
                $v = strtoupper($v);
                if (!preg_match('/^[A-Z][0-9][0-9AB](\\.[0-9A-Z]{1,4})?$/', $v)) return ["$l must look like J02.9 or U07.1 (a letter, two characters, optionally a dot and up to 4 more).", $v];
                return [null, $v];
            }

            case 'bp': {
                $v = preg_replace('/\\s+/', '', $v);
                if (!preg_match('/^([0-9]{2,3})\\/([0-9]{2,3})$/', $v, $m)) return ["$l must look like 120/80.", $v];
                $sys = (int)$m[1]; $dia = (int)$m[2];
                if ($sys < 50 || $sys > 260 || $dia < 30 || $dia > 160) return ["$l is out of range (systolic 50-260, diastolic 30-160).", $v];
                if ($sys <= $dia) return ["$l must have a systolic value higher than the diastolic value.", $v];
                return [null, $v];
            }
        }
        return [null, $v];
    }
}
}
