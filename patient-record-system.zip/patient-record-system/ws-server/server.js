// ============================================================
// Queue WebSocket server
//   Doctor clicks "Call Next Patient"  ->  every signed-in Frontdesk (Staff)
//   browser gets a SweetAlert saying who is next.
//
// Run:   cd ws-server && npm install && npm start      (default port 8080)
// Other port:  PORT=9000 npm start   (then change WS_PORT in js/queue-socket.js)
// ============================================================
const { WebSocketServer, WebSocket } = require("ws");

const PORT = Number(process.env.PORT) || 8080;
const wss = new WebSocketServer({ port: PORT });

// socket -> { role, userId, name }
const clients = new Map();

const send = (ws, obj) => {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
};

const str = (v, max = 200) => (v === null || v === undefined ? "" : String(v).slice(0, max));

wss.on("connection", (ws) => {
  ws.isAlive = true;
  ws.on("pong", () => (ws.isAlive = true));

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    // 1) Every page announces who it is right after connecting
    if (msg.type === "register") {
      clients.set(ws, { role: str(msg.role, 20), userId: msg.userId, name: str(msg.name) });
      send(ws, { type: "registered" });
      return;
    }

    const me = clients.get(ws);
    if (!me) return; // must register first

    // 2) Doctor -> Frontdesk
    if (msg.type === "call-next") {
      if (me.role !== "Doctor") {
        send(ws, { type: "error", reqId: msg.reqId, message: "Only doctors can call the next patient." });
        return;
      }
      const n = msg.next || null;
      const out = {
        type: "next-patient",
        doctorName: str(msg.doctorName || me.name),
        finishedPatient: str(msg.finishedPatient),
        next: n && {
          appointmentId: n.appointmentId,
          patientName: str(n.patientName),
          queueNumber: n.queueNumber,
          time: str(n.time, 20),
          reason: str(n.reason),
        },
        calledAt: new Date().toISOString(),
      };

      let delivered = 0;
      for (const [client, info] of clients) {
        if (info.role === "Staff") { send(client, out); delivered++; }
      }
      console.log(`[${new Date().toLocaleTimeString()}] ${out.doctorName} called ${out.next ? out.next.patientName : "(nobody)"} -> ${delivered} frontdesk screen(s)`);
      send(ws, { type: "call-sent", reqId: msg.reqId, delivered });
    }
  });

  ws.on("close", () => clients.delete(ws));
  ws.on("error", () => clients.delete(ws));
});

// Drop dead connections (closed laptops, lost wifi)
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { clients.delete(ws); ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);

console.log(`Queue WebSocket server running on ws://localhost:${PORT}`);
