-- ============================================================
-- Staff now record the patient intake (Reason, Chief Complaint,
-- Symptoms + vital signs) on the APPOINTMENT. The consultation
-- shows these automatically; the doctor only adds Treatment,
-- ICD-10 diagnoses, prescriptions and Notes.
-- Run once (after vital-signs-by-appointment.sql).
-- ============================================================
USE patient_record_system;

ALTER TABLE APPOINTMENT
    ADD COLUMN ChiefComplaint TEXT NULL,
    ADD COLUMN Symptoms       TEXT NULL;

-- Back-fill from consultations that already have these values
UPDATE APPOINTMENT a
JOIN CONSULTATION c ON c.AppointmentID = a.AppointmentID
SET a.ChiefComplaint = c.ChiefComplaint,
    a.Symptoms       = c.Symptoms;
