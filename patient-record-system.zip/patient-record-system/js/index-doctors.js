import { cmpText, cmpNum, sortBySelect } from "./sort-utils.js?v=20261107";
import { viewModal } from "./modules-doctors/view.js?v=20261107";
import { updateModal } from "./modules-doctors/update.js?v=20261107";
import { deleteModal } from "./modules-doctors/delete.js?v=20261107";

const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const SORTS = {
  "last-asc":   (a, b) => cmpText(a.LastName, b.LastName) || cmpText(a.FirstName, b.FirstName),
  "last-desc":  (a, b) => cmpText(b.LastName, a.LastName) || cmpText(b.FirstName, a.FirstName),
  "first-asc":  (a, b) => cmpText(a.FirstName, b.FirstName) || cmpText(a.LastName, b.LastName),
  "first-desc": (a, b) => cmpText(b.FirstName, a.FirstName) || cmpText(b.LastName, a.LastName),
  "status-asc": (a, b) => cmpText(a.Status, b.Status) || cmpText(a.LastName, b.LastName),
};

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("sort-by").addEventListener("change", () => displayDoctors());
  displayDoctors();

  document.getElementById("show-inactive").addEventListener("change", () => {
    displayDoctors();
  });
});

const displayDoctors = async () => {
  const response = await axios.get(`${baseApiUrl}/doctors.php`, {
    params: { operation: "getAllDoctors" },
  });
  if (response.status == 200) {
    displayDoctorsTable(response.data);
  } else {
    alert("Error!");
  }
};

const displayDoctorsTable = (doctors) => {
  const showInactive = document.getElementById("show-inactive").checked;
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");

  const thead = document.createElement("thead");
  thead.innerHTML = `
    <tr>
      <th>LAST NAME</th>
      <th>FIRST NAME</th>
      <th>USERNAME</th>
      <th>PHONE</th>
      <th>SPECIALIZATIONS</th>
      <th>STATUS</th>
      <th>ACTION</th>
    </tr>
  `;
  table.appendChild(thead);

  const tbody = document.createElement("tbody");

  sortBySelect(doctors, SORTS)
    .filter((doctor) => showInactive || doctor.Status === "Active")
    .forEach((doctor) => {
      const isActive = doctor.Status === "Active";
      let row = document.createElement("tr");
      if (!isActive) row.classList.add("table-secondary");

      row.innerHTML = `
        <td>${doctor.LastName}</td>
        <td>${doctor.FirstName}</td>
        <td>${doctor.Username}</td>
        <td>${doctor.Phone ?? ""}</td>
        <td>${doctor.Specializations ?? ""}</td>
        <td>
          <span class="badge ${isActive ? "bg-success" : "bg-secondary"}">${doctor.Status}</span>
        </td>
        <td>
          <button type="button" class="btn btn-primary btn-sm btn-view">View</button>
          <button type="button" class="btn btn-success btn-sm btn-update">Edit</button>
          ${
            isActive
              ? `<button type="button" class="btn btn-danger btn-sm btn-delete">Deactivate</button>`
              : `<button type="button" class="btn btn-warning btn-sm btn-restore">Restore</button>`
          }
        </td>
      `;
      tbody.appendChild(row);

      row.querySelector(".btn-view").addEventListener("click", () => {
        viewModal(doctor.UserID);
      });

      row.querySelector(".btn-update").addEventListener("click", () => {
        updateModal(doctor.UserID, displayDoctors);
      });

      const deleteBtn = row.querySelector(".btn-delete");
      if (deleteBtn) {
        deleteBtn.addEventListener("click", () => {
          deleteModal(doctor.UserID, displayDoctors);
        });
      }

      const restoreBtn = row.querySelector(".btn-restore");
      if (restoreBtn) {
        restoreBtn.addEventListener("click", () => {
          restoreDoctor(doctor.UserID);
        });
      }
    });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

const restoreDoctor = async (userId) => {
  const params = {
    operation: "restoreDoctor",
    json: JSON.stringify({ userId: userId }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/doctors.php`, {
    params: params,
  });
  if (response.data == 1) {
    displayDoctors();
    alert("Doctor restored!");
  } else {
    alert("ERROR");
  }
};
