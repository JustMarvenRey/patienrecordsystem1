// Shared helpers for the "Sort by" dropdowns on list pages.
export const cmpText = (a, b) =>
  String(a ?? "").localeCompare(String(b ?? ""), undefined, { sensitivity: "base" });
export const cmpNum = (a, b) => (parseFloat(a) || 0) - (parseFloat(b) || 0);
export const cmpRaw = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

// Returns a sorted copy of rows using the option picked in #sort-by
export const sortBySelect = (rows, sorts) => {
  const key = document.getElementById("sort-by")?.value;
  const fn = sorts[key] ?? Object.values(sorts)[0];
  return [...rows].sort(fn);
};
