import { callNextPatient } from "./queue-socket.js?v=20261114";
const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const user = JSON.parse(sessionStorage.getItem("currentUser"));
const isAdmin = user ? user.RoleName === 'Admin' : false;
const isDoctor = user ? user.RoleName === 'Doctor' : false;
// Admin + Staff see every doctor's consultations, so they get the Doctor column
const showDoctorCol = !isDoctor;
const isStaff = user ? user.RoleName === 'Staff' : false; // view-only on this page

document.addEventListener("DOMContentLoaded", () => {
  // Doctor column only exists for Admin + Staff, so only offer that sort to them
  // Changing the sort or a filter goes back to page 1
  const firstPage = () => { pagerState.page = 1; renderSorted(); };
  document.getElementById("sort-by").addEventListener("change", firstPage);
  wireStatusTabs();
  displayConsultations();

  // Doctor: call the next patient straight from this page
  const slot = document.getElementById("call-next-slot");
  if (isDoctor && slot) {
    slot.innerHTML = `<button type="button" class="btn btn-success" id="btn-call-next-page">&#x1F4E2; Call Next Patient</button>`;
    document.getElementById("btn-call-next-page").addEventListener("click", () => {
      // Queue is worked out from today's last finished consultation; with none yet, from today's start of day
      const today = Validate.todayStr();
      const last = consultationRows
        .filter((r) => r.ConsultationID && r.ConsultationStatus !== "Inactive" && r.AppointmentDate === today)
        .sort((a, b) => cmpRaw(dateTimeKey(b), dateTimeKey(a)))[0] || null;
      callNextPatient(last);
    });
  }
});

// ── Sorting ─────────────────────────────────────────────────────────────────
let consultationRows = [];
const pagerState = { page: 1, size: 10 };

const cmpRaw = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
const dateTimeKey = (r) => `${r.AppointmentDate} ${r.AppointmentTime ?? ""}`;

const CONSULT_SORTS = {
  // Next up: appointments still waiting for a consultation first, soonest date & time at the
  // top so it is clear who is next; everything else after, newest first.
  "next":             (a, b) => {
    const wa = !a.ConsultationID && a.AppointmentStatus === "Scheduled" ? 0 : 1;
    const wb = !b.ConsultationID && b.AppointmentStatus === "Scheduled" ? 0 : 1;
    if (wa !== wb) return wa - wb;
    const c = cmpRaw(dateTimeKey(a), dateTimeKey(b));
    if (wa === 0) return c || a.AppointmentID - b.AppointmentID;
    return -c || b.AppointmentID - a.AppointmentID;
  },
  "date-desc":        (a, b) => cmpRaw(dateTimeKey(b), dateTimeKey(a)),
  "date-asc":         (a, b) => cmpRaw(dateTimeKey(a), dateTimeKey(b)),
};

// ── Status tabs: Scheduled / Completed / Cancelled are shown as separate lists ──
const KNOWN_STATUSES = ["Scheduled", "Completed", "Cancelled"];
let activeStatus = "Scheduled";
const statusGroup = (r) => (KNOWN_STATUSES.includes(r.AppointmentStatus) ? r.AppointmentStatus : "Other");

const wireStatusTabs = () => {
  document.querySelectorAll("#status-tabs [data-status]").forEach((btn) =>
    btn.addEventListener("click", () => {
      activeStatus = btn.dataset.status;
      pagerState.page = 1;
      renderSorted();
    })
  );
};

const updateStatusTabs = () => {
  const counts = { Scheduled: 0, Completed: 0, Cancelled: 0, Other: 0 };
  consultationRows.forEach((r) => counts[statusGroup(r)]++);
  if (activeStatus === "Other" && counts.Other === 0) activeStatus = "Scheduled";
  Object.keys(counts).forEach((k) => (document.getElementById(`count-${k}`).textContent = counts[k]));
  document.getElementById("tab-other").style.display = counts.Other > 0 ? "" : "none";
  document.querySelectorAll("#status-tabs [data-status]").forEach((btn) =>
    btn.classList.toggle("active", btn.dataset.status === activeStatus)
  );
};

const renderSorted = () => {
  const sortKey = document.getElementById("sort-by").value;
  updateStatusTabs();
  const rows = consultationRows.filter((r) => statusGroup(r) === activeStatus);
  const sorted = rows.sort(CONSULT_SORTS[sortKey]);
  renderTable(Pager.paginate(pagerState, sorted));
  Pager.controls(document.getElementById("pager"), pagerState, sorted.length, renderSorted);
};

// ── Fetch & render ─────────────────────────────────────────────────────────
const displayConsultations = async () => {
  if (!user) return;

  const response = await axios.get(`${baseApiUrl}/consultations.php`, {
    params: {
      operation: "getAppointmentsByDoctor",
      json: JSON.stringify({ userId: user.UserID, role: user.RoleName }),
    },
  });

  if (response.status === 200) {
    consultationRows = response.data;
    renderSorted();
  } else {
    alert("Error loading consultations.");
  }
};

const renderTable = (rows) => {
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  if (!rows || rows.length === 0) {
    tableDiv.innerHTML = `<p class="text-muted">No appointments found for your account.</p>`;
    return;
  }

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");

  table.innerHTML = `
    <thead>
      <tr>
        <th class="text-nowrap">REQUESTED</th>
        <th>DATE</th>
        <th>TIME</th>
        <th>PATIENT</th>
        ${showDoctorCol ? '<th>DOCTOR</th>' : ''}
        <th>REASON</th>
        <th class="text-nowrap">APPT STATUS</th>
        <th class="text-nowrap">CONSULTATION</th>
        <th class="text-nowrap">ACTION</th>
      </tr>
    </thead>
  `;

  const tbody = document.createElement("tbody");

  rows.forEach((row) => {
    const hasConsultation = !!row.ConsultationID;
    const isInactive = hasConsultation && row.ConsultationStatus === "Inactive";
    const canAdd = isDoctor && ["Confirmed", "Scheduled", "Pending"].includes(row.AppointmentStatus);
    // A consultation can only be dated between the appointment date and today, so an
    // appointment that is still in the future can't be consulted yet.
    const notYet = canAdd && row.AppointmentDate > Validate.todayStr();
    const apptBadge = badgeColor(row.AppointmentStatus);
    const tr = document.createElement("tr");
    if (isInactive) tr.classList.add("table-secondary");

    let consultCell;
    if (!hasConsultation) consultCell = `<span class="badge bg-secondary">None</span>`;
    else if (isInactive) consultCell = `<span class="badge bg-dark">Inactive</span>`;
    else consultCell = `<span class="badge bg-success">Recorded</span>`;

    let actionCell;
    if (hasConsultation) {
      actionCell = `<button class="btn btn-primary btn-sm btn-view-consult">View</button>`;
      if (!isInactive && !isStaff) actionCell += `<button class="btn btn-success btn-sm btn-update-consult">Edit</button>`;
      if (!isInactive && isDoctor) actionCell += `<button class="btn btn-outline-success btn-sm btn-call-next text-nowrap" title="Tell the Frontdesk to send in the next patient">&#x1F4E2; Call Next Patient</button>`;
      if (isAdmin) {
        actionCell += isInactive
          ? `<button class="btn btn-warning btn-sm btn-restore-consult">Restore</button>`
          : `<button class="btn btn-danger btn-sm btn-deactivate-consult">Deactivate</button>`;
      }
    } else if (notYet) {
      actionCell = `<button class="btn btn-secondary btn-sm" disabled
        title="This appointment is on ${row.AppointmentDate}. A consultation can be recorded on or after that date.">Not yet — ${row.AppointmentDate}</button>`;
    } else if (canAdd) {
      actionCell = `<button class="btn btn-warning btn-sm btn-add-consult">Add Consultation</button>`;
    } else {
      actionCell = `<span class="text-muted small">—</span>`;
    }

    tr.innerHTML = `
      <td class="text-nowrap small">${row.CreatedAt ? row.CreatedAt.slice(0, 16).replace("T", " ") : "—"}</td>
      <td class="text-nowrap">${row.AppointmentDate}</td>
      <td class="text-nowrap">${formatTime(row.AppointmentTime)}</td>
      <td>${row.PatientName}</td>
      ${showDoctorCol ? `<td>${row.DoctorName ?? ''}</td>` : ''}
      <td>${row.Reason ?? ""}</td>
      <td><span class="badge ${apptBadge}">${row.AppointmentStatus}</span></td>
      <td>${consultCell}</td>
      <td class="text-nowrap"><div class="d-flex flex-nowrap gap-1">${actionCell}</div></td>
    `;

    tbody.appendChild(tr);

    tr.querySelector(".btn-view-consult")?.addEventListener("click", () => {
      window.location.href = `consultation-detail.html?id=${row.ConsultationID}`;
    });
    tr.querySelector(".btn-update-consult")?.addEventListener("click", () => showConsultationForm(row, true));
    tr.querySelector(".btn-call-next")?.addEventListener("click", () => callNextPatient(row));
    tr.querySelector(".btn-deactivate-consult")?.addEventListener("click", () => deactivateConsultation(row));
    tr.querySelector(".btn-restore-consult")?.addEventListener("click", () => restoreConsultation(row));
    tr.querySelector(".btn-add-consult")?.addEventListener("click", () => showConsultationForm(row, false));
  });

  table.appendChild(tbody);
  NameList.apply(table, { nameHeader: "PATIENT" });  // names only; click a name for the full details
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

// ── Add / Update form modal (tabs) ──────────────────────────────────────────
const escH = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const getList = async (url, operation) => (await axios.get(`${baseApiUrl}/${url}`, { params: { operation } })).data;

const post = async (url, operation, data) => {
  const fd = new FormData();
  fd.append("operation", operation);
  fd.append("json", JSON.stringify(data));
  return (await axios({ url: `${baseApiUrl}/${url}`, method: "POST", data: fd })).data;
};

const showConsultationForm = async (row, isUpdate) => {
  const today = Validate.todayStr(); // local date (toISOString would give the UTC date)
  if (!isUpdate && row.AppointmentDate > today) {
    alert(`This appointment is on ${row.AppointmentDate}. A consultation can be recorded on or after that date.`);
    return;
  }

  document.getElementById("consultation-modal-title").innerText = isUpdate ? "Edit Consultation" : "Add Consultation";

  // Lookup lists for the Diagnosis / Prescribe / Laboratory tabs (a new consultation only)
  let diagnoses = [], medicines = [], tests = [];
  if (!isUpdate) {
    try {
      [diagnoses, medicines, tests] = await Promise.all([
        getList("diagnoses.php", "getActiveDiagnoses"),
        getList("prescriptions.php", "getActiveMedicines"),
        getList("laboratory.php", "getActiveTests"),
      ]);
    } catch (e) {
      alert("Could not load the diagnosis, medicine and laboratory lists. Please try again.");
      return;
    }
  }

  // Has this patient been seen before? (their other consultations, newest first)
  let history = [];
  let historyMod = null;
  let historyFailed = false;
  try {
    historyMod = await import("./modules/view.js?v=20261107");
    history = (await historyMod.fetchHistory(row.PatientID))
      .filter((c) => !isUpdate || String(c.ConsultationID) !== String(row.ConsultationID));
  } catch (e) {
    history = [];   // the rest of the form still works without the history
    historyFailed = true;
  }
  const last = history[0];
  // Only a button — the patient's history stays hidden until it is clicked
  const returningBanner = last ? `
    <div class="mb-3" id="returning-banner">
      <button type="button" class="btn btn-outline-info btn-sm" id="btn-open-records">🗂 View Medical History (${history.length})</button>
    </div>` : "";

  // What the doctor adds in the tabs is kept here and saved together with the consultation.
  const picked = { dx: [], rx: [], lab: [] };

  const tabs = isUpdate
    ? [["treatment", "📝 Treatment"]]
    : [["diagnosis", "🩺 Diagnosis"], ["treatment", "📝 Treatment"], ["rx", "💊 Prescribe Medicine"], ["lab", "🧪 Laboratory Test"]];

  const diagnosisPane = `
    <div class="row g-2 align-items-end">
      <div class="col">
        <label class="form-label">Diagnosis (ICD-10)</label>
        <select class="form-select" id="n-dx-select">
          <option value="">-- Select a diagnosis --</option>
          ${diagnoses.map((d) => `<option value="${escH(d.DiagnosisID)}">${escH(d.ICD10Code)} — ${escH(d.DiagnosisName)}</option>`).join("")}
        </select>
      </div>
      <div class="col-auto"><button type="button" class="btn btn-primary btn-sm" id="n-dx-add">Add</button></div>
    </div>
    <div class="form-text" id="n-dx-desc"></div>
    <div id="n-dx-list" class="mt-2"></div>`;

  const treatmentPane = `
    <div class="mb-2">
      <label class="form-label">Treatment</label>
      <textarea class="form-control" id="f-treatment" data-v="consultation.treatment" rows="3">${isUpdate ? escH(row.Treatment ?? "") : ""}</textarea>
    </div>
    <div class="mb-2">
      <label class="form-label">Notes</label>
      <textarea class="form-control" id="f-notes" data-v="consultation.notes" rows="3">${isUpdate ? escH(row.ConsultationNotes ?? "") : ""}</textarea>
    </div>`;

  const rxPane = `
    <div class="row g-2">
      <div class="col-12">
        <label class="form-label">Medicine</label>
        <select class="form-select" id="n-rx-medicine" data-v="prescription.medicineId">
          <option value="">-- Select Medicine --</option>
          ${medicines.map((m) => `<option value="${escH(m.MedicineID)}">${escH(m.MedicineName)} (${escH(m.GenericName)}) — ${escH(m.DosageForm ?? "")}</option>`).join("")}
        </select>
      </div>
      <div class="col-md-4"><label class="form-label">Dosage</label>
        <input type="text" class="form-control" id="n-rx-dosage" data-v="prescription.dosage" placeholder="e.g. 500mg" /></div>
      <div class="col-md-4"><label class="form-label">Frequency</label>
        <input type="text" class="form-control" id="n-rx-frequency" data-v="prescription.frequency" placeholder="e.g. 3x a day" /></div>
      <div class="col-md-4"><label class="form-label">Duration</label>
        <input type="text" class="form-control" id="n-rx-duration" data-v="prescription.duration" placeholder="e.g. 7 days" /></div>
      <div class="col-12"><label class="form-label">Instructions</label>
        <textarea class="form-control" id="n-rx-instructions" data-v="prescription.instructions" rows="2" placeholder="e.g. Take after meals"></textarea></div>
      <div class="col-12"><button type="button" class="btn btn-primary btn-sm" id="n-rx-add">Add Medicine</button></div>
    </div>
    <div id="n-rx-list" class="mt-3"></div>`;

  const labPane = `
    <div class="row g-2">
      <div class="col-md-8">
        <label class="form-label">Laboratory Test</label>
        <select class="form-select" id="n-lab-test" data-v="lab.testId">
          <option value="">-- Select Test --</option>
          ${tests.map((t) => `<option value="${escH(t.TestID)}" data-normal="${escH(t.NormalRange ?? "")}">${escH(t.TestName)}</option>`).join("")}
        </select>
        <div class="form-text" id="n-lab-hint"></div>
      </div>
      <div class="col-md-4"><label class="form-label">Test Date</label>
        <input type="date" class="form-control" id="n-lab-date" data-v="lab.testDate" min="${escH(row.AppointmentDate)}" max="${today}" value="${today}" /></div>
      <div class="col-12"><label class="form-label">Reference Range</label>
        <input type="text" class="form-control" id="n-lab-range" data-v="lab.referenceRange" placeholder="e.g. 70–100 mg/dL" /></div>
      <div class="col-12"><label class="form-label">Result <span class="text-muted">(optional — can be added later)</span></label>
        <textarea class="form-control" id="n-lab-result" data-v="lab.result" rows="2" placeholder="Enter the result details here..."></textarea></div>
      <div class="col-12"><button type="button" class="btn btn-primary btn-sm" id="n-lab-add">Add Test</button></div>
    </div>
    <div id="n-lab-list" class="mt-3"></div>`;

  const panes = { diagnosis: diagnosisPane, treatment: treatmentPane, rx: rxPane, lab: labPane };

  document.getElementById("consultation-modal-body").innerHTML = `
    <div class="row g-2 mb-2">
      <div class="col-md-6"><div class="small text-muted fw-bold">Patient</div><div>${escH(row.PatientName)}</div></div>
      <div class="col-md-6"><div class="small text-muted fw-bold">Appointment</div>
        <div>${escH(row.AppointmentDate)} ${escH(formatTime(row.AppointmentTime))}${row.Reason ? ` — ${escH(row.Reason)}` : ""}</div></div>
    </div>
    <div class="mb-3">
      <label class="form-label">Consultation Date <span class="text-danger">*</span></label>
      <input type="date" class="form-control" id="f-consult-date" data-v="consultation.consultationDate"
             min="${escH(row.AppointmentDate)}" max="${today}" value="${isUpdate ? escH(row.ConsultationDate) : today}" />
      <div class="form-text">Between the appointment date (${escH(row.AppointmentDate)}) and today.</div>
    </div>
    ${returningBanner}
    <ul class="nav nav-tabs mb-3 flex-nowrap" id="consult-tabs" style="overflow-x:auto;overflow-y:hidden;">
      ${tabs.map(([key, label], i) => `
        <li class="nav-item"><button type="button" class="nav-link ${i === 0 ? "active" : ""}" data-pane="${key}" style="white-space:nowrap;padding:.4rem .6rem;font-size:.85rem;">${label}<span class="badge bg-secondary ms-1 d-none" id="n-count-${key}">0</span></button></li>`).join("")}
    </ul>
    ${tabs.map(([key], i) => `<div class="consult-pane ${i === 0 ? "" : "d-none"}" id="pane-${key}">${panes[key]}</div>`).join("")}
  `;

  // ── tab switching ──
  document.getElementById("consult-tabs").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-pane]");
    if (!btn) return;
    document.querySelectorAll("#consult-tabs .nav-link").forEach((b) => b.classList.toggle("active", b === btn));
    document.querySelectorAll(".consult-pane").forEach((p) => p.classList.toggle("d-none", p.id !== `pane-${btn.dataset.pane}`));
  });
  // The patient's overall medical records open in their own window (also shown automatically after saving)
  document.getElementById("btn-open-records")?.addEventListener("click", () =>
    showRecordsModal({
      title: `Medical Records — ${row.PatientName}`,
      intro: `<div class="text-muted small mb-2">Previous visits before this consultation.</div>`,
      list: history,
      failed: historyFailed,
      emptyText: "No previous consultations. This is the patient's first visit.",
    }));

  const setCount = (key, n) => {
    const b = document.getElementById(`n-count-${key}`);
    if (!b) return;
    b.textContent = n;
    b.classList.toggle("d-none", n === 0);
  };
  const listHtml = (items, labelFn, key) => items.length === 0
    ? `<div class="text-muted small">Nothing added yet.</div>`
    : items.map((it, i) => `
        <div class="d-flex justify-content-between align-items-start border rounded p-2 mb-1">
          <div class="small">${labelFn(it)}</div>
          <button type="button" class="btn btn-danger btn-sm ms-2" data-remove="${key}" data-index="${i}">Remove</button>
        </div>`).join("");

  const redraw = () => {
    if (isUpdate) return;
    document.getElementById("n-dx-list").innerHTML  = listHtml(picked.dx,  (d) => `<strong>${escH(d.label)}</strong>`, "dx");
    document.getElementById("n-rx-list").innerHTML  = listHtml(picked.rx,  (r) => `<strong>${escH(r.label)}</strong>${[r.dosage, r.frequency, r.duration].filter(Boolean).length ? ` — ${escH([r.dosage, r.frequency, r.duration].filter(Boolean).join(" · "))}` : ""}${r.instructions ? `<div class="text-muted">${escH(r.instructions)}</div>` : ""}`, "rx");
    document.getElementById("n-lab-list").innerHTML = listHtml(picked.lab, (l) => `<strong>${escH(l.label)}</strong> — ${escH(l.testDate)}${l.result ? `<div class="text-muted">${escH(l.result)}</div>` : ""}`, "lab");
    setCount("diagnosis", picked.dx.length); setCount("rx", picked.rx.length); setCount("lab", picked.lab.length);
  };

  if (!isUpdate) {
    // Diagnosis
    const dxSelect = document.getElementById("n-dx-select");
    dxSelect.addEventListener("change", () => {
      const d = diagnoses.find((x) => String(x.DiagnosisID) === dxSelect.value);
      document.getElementById("n-dx-desc").textContent = d?.Description ?? "";
    });
    document.getElementById("n-dx-add").addEventListener("click", () => {
      const d = diagnoses.find((x) => String(x.DiagnosisID) === dxSelect.value);
      if (!d) { alert("Please select a diagnosis."); return; }
      if (picked.dx.some((x) => x.diagnosisId === d.DiagnosisID)) { alert("This diagnosis is already added."); return; }
      picked.dx.push({ diagnosisId: d.DiagnosisID, label: `${d.ICD10Code} — ${d.DiagnosisName}` });
      dxSelect.value = "";
      document.getElementById("n-dx-desc").textContent = "";
      redraw();
    });

    // Prescribe medicine
    document.getElementById("n-rx-add").addEventListener("click", () => {
      const sel = document.getElementById("n-rx-medicine");
      const m = medicines.find((x) => String(x.MedicineID) === sel.value);
      const data = {
        medicineId: sel.value,
        prescriptionDate: document.getElementById("f-consult-date").value || today,
        dosage: document.getElementById("n-rx-dosage").value.trim() || null,
        frequency: document.getElementById("n-rx-frequency").value.trim() || null,
        duration: document.getElementById("n-rx-duration").value.trim() || null,
        instructions: document.getElementById("n-rx-instructions").value.trim() || null,
      };
      if (!Validate.ok("prescription", data)) return;
      picked.rx.push({ ...data, label: `${m.MedicineName} (${m.GenericName})` });
      ["n-rx-dosage", "n-rx-frequency", "n-rx-duration", "n-rx-instructions"].forEach((id) => (document.getElementById(id).value = ""));
      sel.value = "";
      redraw();
    });

    // Laboratory test
    const labSel = document.getElementById("n-lab-test");
    labSel.addEventListener("change", () => {
      const nr = labSel.selectedOptions[0]?.getAttribute("data-normal") ?? "";
      document.getElementById("n-lab-hint").textContent = nr ? `Normal range: ${nr}` : "";
    });
    document.getElementById("n-lab-add").addEventListener("click", () => {
      const t = tests.find((x) => String(x.TestID) === labSel.value);
      const data = {
        testId: labSel.value,
        testDate: document.getElementById("n-lab-date").value,
        result: document.getElementById("n-lab-result").value.trim() || null,
        referenceRange: document.getElementById("n-lab-range").value.trim() || null,
      };
      if (!Validate.ok("lab", data)) return;
      picked.lab.push({ ...data, label: t.TestName });
      ["n-lab-result", "n-lab-range"].forEach((id) => (document.getElementById(id).value = ""));
      labSel.value = "";
      document.getElementById("n-lab-hint").textContent = "";
      redraw();
    });

    document.getElementById("consultation-modal-body").addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-remove]");
      if (!btn) return;
      picked[btn.dataset.remove].splice(Number(btn.dataset.index), 1);
      redraw();
    });
    redraw();
  }

  const footer = document.getElementById("consultation-modal-footer");
  footer.innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-consult">
      ${isUpdate ? "Save Changes" : "Save Consultation"}
    </button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("consultation-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-consult").addEventListener("click", async () => {
    const payload = {
      consultationDate: document.getElementById("f-consult-date").value,
      treatment: document.getElementById("f-treatment").value,
      notes:     document.getElementById("f-notes").value,
    };
    if (!Validate.ok("consultation", payload)) return;
    if (payload.consultationDate < row.AppointmentDate) {
      alert(`Consultation date must not be earlier than the appointment date (${row.AppointmentDate}). Pick a date from ${row.AppointmentDate} to ${today}.`);
      return;
    }

    // Ask the doctor to confirm before anything is saved
    const confirmed = await showConfirm(
      isUpdate
        ? `Save the changes to the consultation for ${row.PatientName}?`
        : `Save this consultation for ${row.PatientName}? Please check the details first.`,
      { type: "confirm", title: isUpdate ? "Save changes" : "Save consultation", confirmText: "Yes, save", cancelText: "Go back" }
    );
    if (!confirmed) return;

    const saveBtn = document.getElementById("btn-save-consult");
    saveBtn.disabled = true;
    const result = isUpdate
      ? await updateConsultation({ consultationId: row.ConsultationID, ...payload })
      : await insertConsultation({ appointmentId: row.AppointmentID, ...payload });

    if (!isUpdate && result?.success == 1) {
      // Save everything the doctor added in the tabs against the new consultation.
      const cid = result.consultationId;
      const failed = [];
      for (const d of picked.dx) {
        const r = await post("consultation-diagnosis.php", "addDiagnosis", { consultationId: cid, diagnosisId: d.diagnosisId });
        if (r != 1) failed.push(`Diagnosis: ${d.label}`);
      }
      for (const r of picked.rx) {
        const res = await post("prescriptions.php", "insertPrescription", {
          consultationId: cid, medicineId: r.medicineId, prescriptionDate: payload.consultationDate,
          dosage: r.dosage, frequency: r.frequency, duration: r.duration, instructions: r.instructions,
        });
        if (res != 1) failed.push(`Medicine: ${r.label}`);
      }
      for (const l of picked.lab) {
        const res = await post("laboratory.php", "insertLaboratory", {
          consultationId: cid, testId: l.testId,
          testDate: l.testDate < payload.consultationDate ? payload.consultationDate : l.testDate,
          result: l.result, referenceRange: l.referenceRange,
        });
        if (res != 1) failed.push(`Lab test: ${l.label}`);
      }
      // wait until the form has fully closed before opening the next window
      await new Promise((resolve) => {
        document.getElementById("consultation-modal").addEventListener("hidden.bs.modal", resolve, { once: true });
        modal.hide();
      });
      if (failed.length) {
        alert(`Consultation saved, but these could not be added:\n- ${failed.join("\n- ")}\nYou can add them on the next page.`);
      }

      // Finished: show the patient's overall medical records, now including this visit
      let all = null;
      try { all = await historyMod.fetchHistory(row.PatientID); } catch (e) { /* handled below */ }
      if (!all) { window.location.href = `consultation-detail.html?id=${cid}`; return; }   // fall back to the old behaviour
      // Only THIS visit is shown (not the patient's earlier consultations)
      const current = all.filter((c) => String(c.ConsultationID) === String(cid));
      await showRecordsModal({
        title: `Medical Records — ${row.PatientName}`,
        intro: `<div class="alert alert-success py-2 small mb-3">✅ Consultation saved. Below is the medical record for this visit.</div>`,
        list: current,
        emptyText: "The saved consultation could not be displayed. Use “Open this consultation” to view it.",
        footerHtml: `
          <button type="button" class="btn btn-success btn-sm me-2" id="btn-call-next-saved">&#x1F4E2; Call Next Patient</button>
          <a class="btn btn-primary btn-sm me-2" href="consultation-detail.html?id=${escH(cid)}">Open this consultation →</a>
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>`,
        onHidden: displayConsultations,
      });
      document.getElementById("btn-call-next-saved")?.addEventListener("click", () => callNextPatient(row));
    } else if (isUpdate && result == 1) {
      modal.hide();
      displayConsultations();
      alert("Consultation updated!");
    } else if (result?.error === "already_has_consultation") {
      saveBtn.disabled = false;
      alert("This appointment already has a consultation recorded.");
    } else {
      saveBtn.disabled = false;
      alert("ERROR saving consultation.");
    }
  });
};

// ── Patient's overall medical records window ────────────────────────────────
// Used after a consultation is saved, and by the "View full medical records" link in the form
// (where it opens on top of the form, so the form is left exactly as the doctor had it).
const showRecordsModal = async ({ title, intro = "", list, failed = false, emptyText, footerHtml, onHidden }) => {
  const el = document.getElementById("records-modal");
  document.getElementById("records-modal-title").textContent = title;
  document.getElementById("records-modal-intro").innerHTML = intro;
  const body = document.getElementById("records-modal-body");
  if (failed) {
    body.innerHTML = `<div class="text-center text-muted py-4">Could not load the patient's medical records. Please try again.</div>`;
  } else {
    const mod = await import("./modules/view.js?v=20261107");
    mod.renderHistory(body, list, emptyText);
  }
  const footer = document.getElementById("records-modal-footer");
  footer.innerHTML =
    footerHtml || `<button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>`;

  // Print button (built in): prints exactly what this window lists
  if (!failed && list.length > 0) {
    footer.insertAdjacentHTML("afterbegin",
      `<button type="button" class="btn btn-outline-secondary btn-sm me-auto" id="btn-print-records">🖨 Print</button>`);
    document.getElementById("btn-print-records").addEventListener("click", () => printRecords(title, body));
  }

  // If it opens on top of the consultation form, keep it above that form
  el.style.zIndex = 1075;
  const modal = new bootstrap.Modal(el, { backdrop: "static" });
  el.addEventListener("shown.bs.modal", () => {
    const backdrops = document.querySelectorAll(".modal-backdrop");
    if (backdrops.length) backdrops[backdrops.length - 1].style.zIndex = 1070;
  }, { once: true });
  el.addEventListener("hidden.bs.modal", () => {
    // the consultation form underneath is still open: give it back its scroll lock
    if (document.querySelector("#consultation-modal.show")) {
      document.body.classList.add("modal-open");
      document.body.style.overflow = "hidden";
    }
    if (onHidden) onHidden();
  }, { once: true });
  modal.show();
};

// ── Print the medical records (built in: no extra page or library needed) ────
// Builds a clean copy of the records in a hidden frame and opens the browser's print dialog
// (choose "Save as PDF" there to keep a digital copy).
const printRecords = (title, bodyEl) => {
  const clone = bodyEl.cloneNode(true);
  // the on-screen list scrolls inside a box; on paper it must run the full length
  clone.querySelectorAll('[style*="max-height"]').forEach((e) => { e.style.maxHeight = "none"; e.style.overflow = "visible"; });

  const printedBy = [user?.FirstName, user?.LastName].filter(Boolean).join(" ");
  const printedOn = new Date().toLocaleString("en-US", { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "2-digit" });

  const frame = document.createElement("iframe");
  frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
  document.body.appendChild(frame);

  let printed = false;
  const doPrint = () => {
    if (printed) return;
    printed = true;
    const w = frame.contentWindow;
    w.onafterprint = () => frame.remove();
    w.focus();
    w.print();
  };
  frame.onload = doPrint;

  const doc = frame.contentWindow.document;
  doc.open();
  doc.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${escH(title)}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
      body { padding: 20px; color: #222; font-size: 13px; background: #fff; }
      * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .doc-head { border-bottom: 2px solid #222; margin-bottom: 14px; padding-bottom: 8px; }
      .doc-head h1 { font-size: 20px; margin: 0; }
      .border.rounded { break-inside: avoid; page-break-inside: avoid; }
      .doc-foot { margin-top: 16px; font-size: 11px; color: #666; text-align: center; }
    </style></head><body>
    <div class="doc-head">
      <h1>Patient Record System — ${escH(title)}</h1>
      <div class="text-muted">Printed ${escH(printedOn)}${printedBy ? ` by ${escH(printedBy)}` : ""}</div>
    </div>
    ${clone.innerHTML}
    <div class="doc-foot">Confidential medical information. System-generated copy.</div>
    </body></html>`);
  doc.close();
  setTimeout(doPrint, 2500);   // in case the page's load event was missed
};

// ── API calls ───────────────────────────────────────────────────────────────
const insertConsultation = async (data) => {
  const fd = new FormData();
  fd.append("operation", "insertConsultation");
  fd.append("json", JSON.stringify(data));
  const res = await axios({ url: `${baseApiUrl}/consultations.php`, method: "POST", data: fd });
  return res.data;
};

const updateConsultation = async (data) => {
  const fd = new FormData();
  fd.append("operation", "updateConsultation");
  fd.append("json", JSON.stringify(data));
  const res = await axios({ url: `${baseApiUrl}/consultations.php`, method: "POST", data: fd });
  return res.data;
};

// ── Deactivate / Restore (Admin only) ───────────────────────────────────────
const CONSULT_ERRORS = { forbidden: "Only an Admin can do that." };

const postConsultStatus = async (operation, row) => {
  const fd = new FormData();
  fd.append("operation", operation);
  fd.append("json", JSON.stringify({ consultationId: row.ConsultationID, actingUserId: user.UserID }));
  const res = await axios({ url: `${baseApiUrl}/consultations.php`, method: "POST", data: fd });
  return res.data;
};

const deactivateConsultation = async (row) => {
  const ok = await showConfirm(
    `Deactivate the consultation for ${row.PatientName} (${row.AppointmentDate})? The record is kept and can be restored later.`,
    { type: "danger", title: "Deactivate consultation", confirmText: "Deactivate", cancelText: "Keep" }
  );
  if (!ok) return;
  const res = await postConsultStatus("deactivateConsultation", row);
  if (res == 1) {
    displayConsultations();
    alert("Consultation has been deactivated!");
  } else {
    alert(CONSULT_ERRORS[res?.error] || "ERROR deactivating consultation.");
  }
};

const restoreConsultation = async (row) => {
  const res = await postConsultStatus("restoreConsultation", row);
  if (res == 1) {
    displayConsultations();
    alert("Consultation restored!");
  } else {
    alert(CONSULT_ERRORS[res?.error] || "ERROR restoring consultation.");
  }
};

// ── Helpers ─────────────────────────────────────────────────────────────────
const formatTime = (t) => {
  if (!t) return "";
  const [h, m] = t.split(":");
  const hr = parseInt(h);
  return `${hr % 12 || 12}:${m} ${hr < 12 ? "AM" : "PM"}`;
};

const badgeColor = (status) => {
  switch (status) {
    case "Completed":  return "bg-success";
    case "Scheduled":  return "bg-primary";
    case "Confirmed":  return "bg-info text-dark";
    case "Pending":    return "bg-warning text-dark";
    case "Cancelled":  return "bg-danger";
    case "No-Show":    return "bg-warning text-dark";
    default:           return "bg-secondary";
  }
};
