// Shared helpers for the Billing module (billing.html + consultation-detail.html).
//
//   Admin : manages bills AND professional fees (and deactivates/restores bills)
//   Staff : handles the bills (create / edit / record payment) AND professional fees
//   Others: read-only

const currentUser = () => {
  const raw = sessionStorage.getItem("currentUser");
  return raw ? JSON.parse(raw) : null;
};

export const actingUserId = () => currentUser()?.UserID ?? null;

export const canManageBills = () => ["Admin", "Staff"].includes(currentUser()?.RoleName);
export const canManageFees = () => ["Admin", "Staff"].includes(currentUser()?.RoleName);
// Deactivating / restoring a whole bill stays Admin-only
export const isAdminRole = () => currentUser()?.RoleName === "Admin";

export const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export const peso = (v) =>
  `₱ ${(parseFloat(v) || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const statusBadge = (status) => {
  switch (status) {
    case "Paid":      return "bg-success";
    case "Pending":   return "bg-warning text-dark";
    case "Cancelled": return "bg-danger";
    default:          return "bg-secondary";
  }
};

export const BILLING_ERRORS = {
  forbidden: "Your role isn't allowed to do that.",
  missing_fields: "Please fill in every required field.",
  invalid_date: "Please enter a valid date.",
  invalid_amount: "Amount must be a valid number (fees must be greater than 0, totals can't be negative).",
  invalid_status: "Please choose a valid status.",
  already_billed: "A bill already exists for this consultation.",
  consultation_not_found: "That consultation no longer exists.",
  not_found: "That record no longer exists.",
  invalid_description: "Please enter a description (up to 150 characters for a laboratory fee).",
  invalid_test: "That laboratory test isn't available.",
  no_set_fee: "That doctor has no professional fee set yet. Ask the Admin to set it in Fee Schedule.",
  invalid_method: "Please choose a payment method.",
  reference_required: "Enter the reference / approval number for this payment.",
  invalid_reference: "The reference number can only have letters, numbers, spaces, - or _ (3-40 characters).",
  duplicate_reference: "That reference number has already been used for another payment.",
  amount_short: "The amount received is less than the amount due.",
  already_paid: "This bill is already paid.",
  not_payable: "This bill can't be paid (it must be a Pending bill with an amount greater than 0).",
  payment_failed: "The payment could not be recorded. Nothing was charged. Please try again.",
  bill_locked: "Only a Pending bill can have its fees changed. A Paid or Cancelled bill's amount is final.",
};

// POSTs a billing operation. Always sends who is acting so the API can check the role.
export const postBilling = async (baseApiUrl, operation, data) => {
  const fd = new FormData();
  fd.append("operation", operation);
  fd.append("json", JSON.stringify({ ...data, actingUserId: actingUserId() }));
  const res = await axios({ url: `${baseApiUrl}/billing.php`, method: "POST", data: fd });
  return res.data;
};

// GET with the acting user attached.
export const getBilling = async (baseApiUrl, operation, data = {}) => {
  const res = await axios.get(`${baseApiUrl}/billing.php`, {
    params: { operation, json: JSON.stringify({ ...data, actingUserId: actingUserId() }) },
  });
  return res.data;
};

// true when the API result is a success (1 or {billId}); otherwise alerts the reason and returns false.
export const checkBillingResult = (data, successMessage) => {
  if (data == 1 || data?.billId) {
    if (successMessage) alert(successMessage);
    return true;
  }
  alert(BILLING_ERRORS[data?.error] || "ERROR");
  return false;
};
