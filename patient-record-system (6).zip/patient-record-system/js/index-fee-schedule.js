import { isAdminRole, esc, postBilling, getBilling, BILLING_ERRORS } from "./modules-billing/common.js?v=20261107";

// Fee Schedule tab on the Billing page (Admin only): the standard amount of each doctor's professional fee and each lab test.
const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

let schedule = { doctors: [], tests: [] };
const doctorPager = { page: 1, size: 10 };
const labPager = { page: 1, size: 10 };

document.addEventListener("DOMContentLoaded", () => {
  if (!isAdminRole()) return;   // Staff never see the tab (and the API refuses them anyway)
  document.getElementById("billing-tabs").classList.remove("d-none");
  document.getElementById("fee-show-inactive").addEventListener("change", () => { labPager.page = 1; render(); });
  load();
});

const load = async () => {
  const data = await getBilling(baseApiUrl, "getFeeSchedule");
  if (data?.error) {
    alert(BILLING_ERRORS[data.error] || "ERROR");
    return;
  }
  schedule = data;
  render();
};

// One editable table: name | amount input | Save
const buildTable = (rows, { idKey, nameKey, amountKey, saveOp, saveIdName, saveLabel }) => {
  if (rows.length === 0) return `<p class="text-muted small mb-0">Nothing to show.</p>`;
  return `
    <table class="table table-sm table-hover align-middle mb-0">
      <thead><tr><th>${saveLabel}</th><th style="width:170px">Amount (₱)</th><th style="width:1%"></th></tr></thead>
      <tbody>
        ${rows.map((r) => `
          <tr class="${r.Status === "Active" ? "" : "table-secondary"}">
            <td>${esc(r[nameKey])}${r.Status === "Active" ? "" : ' <span class="badge bg-secondary">Inactive</span>'}</td>
            <td>
              <input type="number" min="0" step="0.01" class="form-control form-control-sm fee-input"
                     data-id="${r[idKey]}" data-orig="${parseFloat(r[amountKey]) || 0}"
                     value="${(parseFloat(r[amountKey]) || 0).toFixed(2)}" />
            </td>
            <td><button type="button" class="btn btn-success btn-sm btn-save-fee" data-id="${r[idKey]}" data-op="${saveOp}" data-idname="${saveIdName}" disabled>Save</button></td>
          </tr>`).join("")}
      </tbody>
    </table>`;
};

const render = () => {
  const showInactive = document.getElementById("fee-show-inactive").checked;

  const labs = schedule.tests.filter((t) => showInactive || t.Status === "Active");

  document.getElementById("doctor-fees").innerHTML = buildTable(Pager.paginate(doctorPager, schedule.doctors), {
    idKey: "UserID", nameKey: "DoctorName", amountKey: "ProfessionalFee",
    saveOp: "updateDoctorFee", saveIdName: "userId", saveLabel: "Doctor",
  });
  Pager.controls(document.getElementById("doctor-pager"), doctorPager, schedule.doctors.length, render);

  document.getElementById("lab-prices").innerHTML = buildTable(Pager.paginate(labPager, labs), {
    idKey: "TestID", nameKey: "TestName", amountKey: "Price",
    saveOp: "updateLabTestPrice", saveIdName: "testId", saveLabel: "Test",
  });
  Pager.controls(document.getElementById("lab-pager"), labPager, labs.length, render);

  // Save is only enabled once the amount was changed
  document.querySelectorAll(".fee-input").forEach((input) => {
    const btn = input.closest("tr").querySelector(".btn-save-fee");
    input.addEventListener("input", () => {
      btn.disabled = (parseFloat(input.value) || 0) === parseFloat(input.dataset.orig) && input.value !== "";
    });
  });

  document.querySelectorAll(".btn-save-fee").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const input = btn.closest("tr").querySelector(".fee-input");
      const amount = input.value;
      const n = Number(amount);
      if (amount === "" || !isFinite(n) || n < 0 || n > 99999999.99) {
        alert("Please enter a valid amount (0 or more).");
        return;
      }
      const res = await postBilling(baseApiUrl, btn.dataset.op, { [btn.dataset.idname]: btn.dataset.id, amount });
      if (res == 1) {
        input.dataset.orig = n;
        input.value = n.toFixed(2);
        btn.disabled = true;
        // keep the in-memory copy in step so toggling "show inactive" doesn't lose the saved value
        const list = btn.dataset.op === "updateDoctorFee" ? schedule.doctors : schedule.tests;
        const row = list.find((r) => String(r[btn.dataset.idname === "userId" ? "UserID" : "TestID"]) === btn.dataset.id);
        if (row) row[btn.dataset.op === "updateDoctorFee" ? "ProfessionalFee" : "Price"] = n.toFixed(2);
        btn.textContent = "Saved ✓";
        setTimeout(() => { btn.textContent = "Save"; }, 1200);
      } else {
        alert(BILLING_ERRORS[res?.error] || "ERROR");
      }
    });
  });
};
