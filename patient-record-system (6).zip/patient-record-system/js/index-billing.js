import { cmpText, cmpNum, cmpRaw, sortBySelect } from "./sort-utils.js?v=20261107";
import {
  actingUserId, canManageBills, canManageFees, isAdminRole, esc, peso, statusBadge,
  postBilling, getBilling, checkBillingResult, BILLING_ERRORS,
} from "./modules-billing/common.js?v=20261107";

const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const SORTS = {
  "date-desc":    (a, b) => cmpRaw(b.BillDate, a.BillDate),
  "date-asc":     (a, b) => cmpRaw(a.BillDate, b.BillDate),
  "patient-asc":  (a, b) => cmpText(a.PatientName, b.PatientName),
  "patient-desc": (a, b) => cmpText(b.PatientName, a.PatientName),
  "doctor-asc":   (a, b) => cmpText(a.DoctorName, b.DoctorName),
  "total-desc":   (a, b) => cmpNum(b.TotalAmount, a.TotalAmount),
  "total-asc":    (a, b) => cmpNum(a.TotalAmount, b.TotalAmount),
  "fees-desc":    (a, b) => cmpNum(b.FeesTotal, a.FeesTotal),
};

const todayStr = () => Validate.todayStr(); // local date (toISOString would give the UTC date)

document.addEventListener("DOMContentLoaded", () => {
  const canFees = canManageFees();
  document.getElementById("billing-subtext").textContent = canFees
    ? "View and manage all patient bills and professional fees."
    : "View patient bills and professional fees.";

  if (canManageBills()) {
    const btn = document.getElementById("btn-create-bill");
    btn.classList.remove("d-none");
    btn.addEventListener("click", showCreateBillModal);
  }

  document.getElementById("status-filter").addEventListener("change", renderTable);
  document.getElementById("sort-by").addEventListener("change", renderTable);
  displayBills();
});

let allBills = [];

// ── Fetch & render all bills ────────────────────────────────────────────────
const displayBills = async () => {
  const data = await getBilling(baseApiUrl, "getAllBills");
  if (!Array.isArray(data)) {
    alert(data?.error === "forbidden" ? "Your role isn't allowed to view billing." : "Error loading billing records.");
    return;
  }
  allBills = data;
  renderTable();
};

const renderTable = () => {
  const filter = document.getElementById("status-filter").value;
  const rows = sortBySelect(allBills.filter((b) => !filter || b.Status === filter), SORTS);

  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  if (rows.length === 0) {
    tableDiv.innerHTML = `<p class="text-muted">No bills found.</p>`;
    return;
  }

  const table = document.createElement("table");
  table.className = "table table-hover table-striped table-sm";
  table.innerHTML = `
    <thead>
      <tr>
        <th>BILL DATE</th>
        <th>PATIENT</th>
        <th>DOCTOR</th>
        <th>APPT DATE</th>
        <th>TOTAL (₱)</th>
        <th class="text-nowrap">PROF. FEES (₱)</th>
        <th class="text-nowrap">LAB TESTS (₱)</th>
        <th>STATUS</th>
        <th class="text-nowrap">ACTION</th>
      </tr>
    </thead>
  `;

  const tbody = document.createElement("tbody");
  rows.forEach((row) => {
    const tr = document.createElement("tr");
    const isCancelled = row.Status === "Cancelled";
    if (isCancelled) tr.classList.add("table-secondary");
    tr.innerHTML = `
      <td>${esc(row.BillDate)}</td>
      <td>${esc(row.PatientName)}</td>
      <td>${esc(row.DoctorName)}</td>
      <td>${esc(row.AppointmentDate)}</td>
      <td>${(parseFloat(row.TotalAmount) || 0).toFixed(2)}</td>
      <td>${
        Number(row.FeesCount) > 0
          ? `${(parseFloat(row.FeesTotal) || 0).toFixed(2)}<div class="small text-muted">${row.FeesCount} fee${Number(row.FeesCount) === 1 ? "" : "s"}</div>`
          : `<span class="text-muted">—</span>`
      }</td>
      <td>${
        Number(row.LabsCount) > 0
          ? `${(parseFloat(row.LabsTotal) || 0).toFixed(2)}<div class="small text-muted">${row.LabsCount} test${Number(row.LabsCount) === 1 ? "" : "s"}</div>`
          : `<span class="text-muted">—</span>`
      }</td>
      <td><span class="badge ${statusBadge(row.Status)}">${esc(row.Status)}</span></td>
      <td class="text-nowrap" style="width: 1%;">
        <div class="d-flex flex-nowrap gap-1">
          <button class="btn btn-primary btn-sm btn-view">View</button>
          ${row.Status === "Paid" ? `<button class="btn btn-info btn-sm btn-receipt">Receipt</button>` : ""}
          ${canManageBills() && row.Status === "Pending" && Number(row.TotalAmount) > 0
            ? `<button class="btn btn-warning btn-sm btn-collect">Collect Payment</button>` : ""}
          ${canManageBills() ? `<button class="btn btn-success btn-sm btn-edit">Edit</button>` : ""}
          ${isAdminRole()
            ? (isCancelled
                ? `<button class="btn btn-warning btn-sm btn-restore">Restore</button>`
                : `<button class="btn btn-danger btn-sm btn-deactivate">Deactivate</button>`)
            : ""}
        </div>
      </td>
    `;
    tbody.appendChild(tr);

    tr.querySelector(".btn-view").addEventListener("click", () => viewBill(row));
    tr.querySelector(".btn-receipt")?.addEventListener("click", () => { window.location.href = `receipt.html?bill=${row.BillID}`; });
    tr.querySelector(".btn-collect")?.addEventListener("click", () => showWalkInPayModal(row));
    tr.querySelector(".btn-edit")?.addEventListener("click", () => showEditBillModal(row));
    tr.querySelector(".btn-deactivate")?.addEventListener("click", () => deactivateBill(row));
    tr.querySelector(".btn-restore")?.addEventListener("click", () => restoreBill(row));
  });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

// ── Deactivate / Restore (Admin only) ───────────────────────────────────────
const deactivateBill = async (bill) => {
  const ok = await showConfirm(
    `Deactivate the bill for ${bill.PatientName} (${bill.BillDate})? It will be marked Cancelled and can be restored later.`,
    { type: "danger", title: "Deactivate bill", confirmText: "Deactivate", cancelText: "Keep" }
  );
  if (!ok) return;
  const res = await postBilling(baseApiUrl, "deactivateBilling", { billId: bill.BillID });
  if (checkBillingResult(res, "Bill has been deactivated!")) displayBills();
};

const restoreBill = async (bill) => {
  const res = await postBilling(baseApiUrl, "restoreBilling", { billId: bill.BillID });
  if (checkBillingResult(res, "Bill restored (set back to Pending).")) displayBills();
};

// ── View Bill modal (with fees) ─────────────────────────────────────────────
const viewBill = async (bill) => {
  document.getElementById("bill-modal-title").innerText = `Bill — ${bill.PatientName}`;

  const fees = await getBilling(baseApiUrl, "getProfessionalFees", { billId: bill.BillID });
  const labs = await getBilling(baseApiUrl, "getLabCharges", { billId: bill.BillID });
  const labList = Array.isArray(labs) ? labs : [];
  const labsTotal = labList.reduce((sum, l) => sum + (parseFloat(l.Price) || 0), 0);
  // Admin can change amounts and add laboratory fees, but only while the bill is still Pending
  const adminEdit = isAdminRole() && bill.Status === "Pending";
  const labsHtml = labList.length > 0
    ? `<table class="table table-sm mt-2">
        <thead><tr><th>Test / fee</th><th>Date</th><th>Amount (₱)</th>${adminEdit ? "<th>Action</th>" : ""}</tr></thead>
        <tbody>${labList.map((l) => `<tr>
          <td>${esc(l.TestName)}${l.Source === "added" ? ` <span class="badge bg-secondary">added</span>` : ""}</td>
          <td class="text-muted small">${esc(l.TestDate ?? "")}</td>
          <td>${(parseFloat(l.Price) || 0).toFixed(2)}</td>
          ${adminEdit ? `<td class="text-nowrap">
            <button class="btn btn-success btn-sm btn-edit-lab" data-source="${esc(l.Source)}" data-id="${esc(l.ChargeID)}">Edit</button>
            ${l.Source === "added" ? `<button class="btn btn-danger btn-sm btn-remove-lab" data-id="${esc(l.ChargeID)}">Remove</button>` : ""}
          </td>` : ""}
        </tr>`).join("")}</tbody>
        <tfoot><tr><th colspan="2" class="text-end">Laboratory subtotal</th><th>${labsTotal.toFixed(2)}</th>${adminEdit ? "<th></th>" : ""}</tr></tfoot>
       </table>`
    : `<p class="text-muted small">No laboratory charges on this bill.</p>`;
  const feeList = Array.isArray(fees) ? fees : [];
  const feesTotal = feeList.reduce((sum, f) => sum + (parseFloat(f.FeeAmount) || 0), 0);
  const canFees = canManageFees();

  const feesHtml = feeList.length > 0
    ? `<table class="table table-sm mt-2">
        <thead><tr><th>Doctor</th><th>Description</th><th>Amount (₱)</th>${canFees ? "<th>Action</th>" : ""}</tr></thead>
        <tbody>
          ${feeList.map((f) => `
            <tr>
              <td>${esc(f.DoctorName)}</td>
              <td class="text-muted small">${esc(f.Description ?? "—")}</td>
              <td>${(parseFloat(f.FeeAmount) || 0).toFixed(2)}</td>
              ${canFees ? `<td class="text-nowrap">
                ${adminEdit ? `<button class="btn btn-success btn-sm btn-edit-fee" data-id="${f.ProfessionalFeeID}">Edit</button>` : ""}
                <button class="btn btn-danger btn-sm btn-remove-fee" data-id="${f.ProfessionalFeeID}">Remove</button></td>` : ""}
            </tr>`).join("")}
        </tbody>
        <tfoot>
          <tr><th colspan="2" class="text-end">Fees subtotal</th><th>${feesTotal.toFixed(2)}</th>${canFees ? "<th></th>" : ""}</tr>
        </tfoot>
       </table>`
    : `<p class="text-muted small">No professional fees recorded.</p>`;

  document.getElementById("bill-modal-body").innerHTML = `
    <table class="table table-sm mb-3">
      <tr><td><strong>Patient</strong></td><td>${esc(bill.PatientName)}</td></tr>
      <tr><td><strong>Doctor</strong></td><td>${esc(bill.DoctorName)}</td></tr>
      <tr><td><strong>Appointment Date</strong></td><td>${esc(bill.AppointmentDate)}</td></tr>
      <tr><td><strong>Bill Date</strong></td><td>${esc(bill.BillDate)}</td></tr>
      <tr><td><strong>Total Amount</strong></td><td>${peso(bill.TotalAmount)}</td></tr>
      <tr><td><strong>Status</strong></td><td><span class="badge ${statusBadge(bill.Status)}">${esc(bill.Status)}</span></td></tr>
    </table>
    <div class="d-flex justify-content-between align-items-center mb-2">
      <strong>Professional Fees</strong>
      ${canFees ? `<button class="btn btn-success btn-sm" id="btn-add-fee-view">+ Add Fee</button>` : ""}
    </div>
    ${feesHtml}
    <div class="d-flex justify-content-between align-items-center mt-3 mb-2">
      <strong>Laboratory Charges</strong>
      ${adminEdit ? `<button class="btn btn-success btn-sm" id="btn-add-lab-view">+ Add Lab Fee</button>` : ""}
    </div>
    ${labsHtml}
    <div class="form-text">Total = professional fees + laboratory charges, calculated automatically.</div>
  `;

  document.getElementById("bill-modal-footer").innerHTML = `
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("bill-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-add-fee-view")?.addEventListener("click", () => {
    modal.hide();
    showAddFeeModal(bill.BillID);
  });

  document.querySelectorAll(".btn-edit-fee").forEach((btn) =>
    btn.addEventListener("click", () => {
      modal.hide();
      showEditFeeModal(bill, feeList.find((f) => String(f.ProfessionalFeeID) === btn.dataset.id));
    }));
  document.getElementById("btn-add-lab-view")?.addEventListener("click", () => {
    modal.hide();
    showAddLabFeeModal(bill);
  });
  document.querySelectorAll(".btn-edit-lab").forEach((btn) =>
    btn.addEventListener("click", () => {
      modal.hide();
      showEditLabFeeModal(bill, labList.find((l) => l.Source === btn.dataset.source && String(l.ChargeID) === btn.dataset.id));
    }));
  document.querySelectorAll(".btn-remove-lab").forEach((btn) =>
    btn.addEventListener("click", async () => {
      if (!(await showConfirm("Remove this laboratory fee from the bill?", { type: "danger", title: "Remove lab fee", confirmText: "Remove" }))) return;
      const res = await postBilling(baseApiUrl, "removeLabCharge", { chargeId: btn.dataset.id });
      if (checkBillingResult(res)) { modal.hide(); reopenBill(bill.BillID); }
    }));

  document.querySelectorAll(".btn-remove-fee").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!(await showConfirm("Remove this fee?", { type: "danger", title: "Remove fee", confirmText: "Remove" }))) return;
      const res = await postBilling(baseApiUrl, "removeProfessionalFee", { professionalFeeId: btn.dataset.id });
      if (checkBillingResult(res)) { modal.hide(); displayBills(); }
    });
  });
};

// ── Create Bill modal (Admin + Staff) ───────────────────────────────────────
const showCreateBillModal = async () => {
  const consultations = await getBilling(baseApiUrl, "getUnbilledConsultations");
  if (!Array.isArray(consultations)) {
    checkBillingResult(consultations);
    return;
  }

  const options = consultations
    .map((c) => `<option value="${c.ConsultationID}">${esc(c.ConsultationDate)} — ${esc(c.PatientName)} (Dr. ${esc(c.DoctorName)})</option>`)
    .join("");

  document.getElementById("create-bill-modal-body").innerHTML = consultations.length === 0
    ? `<p class="text-muted mb-0">Every consultation already has a bill.</p>`
    : `
      <div class="mb-2">
        <label class="form-label">Consultation <span class="text-danger">*</span></label>
        <select class="form-select" id="create-bill-consultation" data-v="bill.consultationId">
          <option value="" disabled selected>-- Select consultation --</option>
          ${options}
        </select>
        <div class="form-text">Only consultations that don't have a bill yet are listed.</div>
      </div>
      <div class="mb-2">
        <label class="form-label">Bill Date <span class="text-danger">*</span></label>
        <input type="date" class="form-control" id="create-bill-date" data-v="bill.billDate" value="${todayStr()}" />
      </div>
      <div class="alert alert-info small mb-0">
        The total is <strong>calculated automatically</strong>: the consulting doctor's professional fee plus the
        laboratory tests recorded for the consultation. Both amounts are set by the Admin in
        <strong>Fee Schedule</strong>${isAdminRole() ? " (you can still adjust a single bill from its View window)" : ""}.
      </div>
    `;

  document.getElementById("create-bill-modal-footer").innerHTML = `
    ${consultations.length > 0 ? `<button type="button" class="btn btn-success btn-sm me-2" id="btn-save-create-bill">Create Bill</button>` : ""}
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("create-bill-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-create-bill")?.addEventListener("click", async () => {
    const consultationId = document.getElementById("create-bill-consultation").value;
    const billDate = document.getElementById("create-bill-date").value;
    if (!Validate.ok("bill", { consultationId, billDate })) return;

    const res = await postBilling(baseApiUrl, "insertBilling", { consultationId, billDate });
    if (!res?.billId) { checkBillingResult(res); return; }

    alert("Bill created! The doctor's professional fee and the laboratory charges were added automatically.");
    modal.hide();
    displayBills();
  });
};

// ── Edit Bill modal (Admin + Staff) ─────────────────────────────────────────
const showEditBillModal = (bill) => {
  const statusOptions = ["Pending", "Paid", "Cancelled"].map((s) =>
    `<option value="${s}" ${bill.Status === s ? "selected" : ""}>${s}</option>`
  ).join("");

  document.getElementById("edit-bill-modal-body").innerHTML = `
    <div class="mb-2">
      <label class="form-label"><strong>Patient:</strong> ${esc(bill.PatientName)}</label>
    </div>
    <div class="mb-2">
      <label class="form-label">Bill Date <span class="text-danger">*</span></label>
      <input type="date" class="form-control" id="edit-bill-date" data-v="bill_update.billDate" value="${esc(bill.BillDate)}" />
    </div>
    <div class="mb-2">
      <label class="form-label">Total Amount</label>
      <div class="form-control bg-light">${peso(bill.TotalAmount)}</div>
      <div class="form-text">Calculated automatically from professional fees + laboratory charges.</div>
    </div>
    <div class="mb-2">
      <label class="form-label">Status</label>
      <select class="form-select" id="edit-bill-status" data-v="bill_update.status">${statusOptions}</select>
      <div class="form-text">Set to <strong>Paid</strong> once the patient has paid.</div>
    </div>
  `;

  document.getElementById("edit-bill-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-edit-bill">Save Changes</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("edit-bill-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-edit-bill").addEventListener("click", async () => {
    const billDate    = document.getElementById("edit-bill-date").value;
    const status      = document.getElementById("edit-bill-status").value;
    if (!Validate.ok("bill_update", { billDate, status })) return;

    const res = await postBilling(baseApiUrl, "updateBilling", { billId: bill.BillID, billDate, status });
    if (checkBillingResult(res)) { modal.hide(); displayBills(); }
  });
};

// ── Add Professional Fee modal (Admin only) ─────────────────────────────────
const showAddFeeModal = async (billId) => {
  document.getElementById("fee-modal-title").textContent = "Add Professional Fee";
  const docRes = await axios.get(`${baseApiUrl}/billing.php`, { params: { operation: "getActiveDoctors" } });
  const doctors = Array.isArray(docRes.data) ? docRes.data : [];
  const rateOf = (id) => parseFloat(doctors.find((d) => String(d.UserID) === String(id))?.ProfessionalFee) || 0;
  const docOptions = doctors.map((d) =>
    `<option value="${d.UserID}">${esc(d.DoctorName)}</option>`
  ).join("");
  const admin = isAdminRole();

  // Amount: the doctor's rate from Fee Schedule. Only the Admin may type a different amount for this bill.
  document.getElementById("fee-modal-body").innerHTML = `
    <div class="mb-2">
      <label class="form-label">Doctor <span class="text-danger">*</span></label>
      <select class="form-select" id="fee-doctor" data-v="fee.userId">
        <option value="" disabled selected>-- Select Doctor --</option>
        ${docOptions}
      </select>
    </div>
    <div class="mb-2">
      <label class="form-label">Fee Amount (₱)</label>
      ${admin
        ? `<input type="number" min="0.01" step="0.01" class="form-control" id="fee-amount" placeholder="Leave blank to use the doctor's set fee" />
           <div class="form-text" id="fee-rate-hint"></div>`
        : `<input type="text" class="form-control" id="fee-amount-readonly" value="" placeholder="Select a doctor" readonly />
           <div class="form-text">The amount comes from the Admin's Fee Schedule.</div>`}
    </div>
    <div class="mb-2">
      <label class="form-label">Description</label>
      <input type="text" class="form-control" id="fee-description" data-v="fee.description" placeholder="e.g. Consultation fee" />
    </div>
  `;

  document.getElementById("fee-doctor").addEventListener("change", (e) => {
    const rate = rateOf(e.target.value);
    const label = rate > 0 ? peso(rate) : "not set";
    if (admin) document.getElementById("fee-rate-hint").textContent = `Set fee for this doctor: ${label}`;
    else document.getElementById("fee-amount-readonly").value = label;
  });

  document.getElementById("fee-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-fee">Add Fee</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("fee-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-fee").addEventListener("click", async () => {
    const userId = document.getElementById("fee-doctor").value;
    const description = document.getElementById("fee-description").value;
    const typed = admin ? document.getElementById("fee-amount").value : "";
    // Check the pieces that are typed; a blank amount means "use the set fee" (the server fills it in)
    if (!Validate.ok("fee", { userId, feeAmount: typed !== "" ? typed : (rateOf(userId) || 1), description })) return;

    const res = await postBilling(baseApiUrl, "insertProfessionalFee", {
      billId,
      userId,
      feeAmount: typed,
      description: description.trim() || null,
    });
    if (checkBillingResult(res)) { modal.hide(); displayBills(); }
  });
};


// ── Admin: change amounts and manage laboratory fees on a Pending bill ─────────
// After saving, the bill is shown again with its new lines and total.
const reopenBill = async (billId) => {
  await displayBills();
  const fresh = allBills.find((b) => String(b.BillID) === String(billId));
  if (fresh) viewBill(fresh);
};

// Fills the small "fee" modal. onSave returns the API result, or undefined if the form isn't valid yet.
const openAmountModal = ({ billId, title, bodyHtml, saveLabel, onSave }) => {
  document.getElementById("fee-modal-title").textContent = title;
  document.getElementById("fee-modal-body").innerHTML = bodyHtml;
  document.getElementById("fee-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-amount">${saveLabel}</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;
  const modal = new bootstrap.Modal(document.getElementById("fee-modal"), { backdrop: "static" });
  modal.show();
  document.getElementById("btn-save-amount").addEventListener("click", async () => {
    const res = await onSave();
    if (res === undefined) return;
    if (checkBillingResult(res)) { modal.hide(); reopenBill(billId); }
  });
};

const showEditFeeModal = (bill, fee) => {
  if (!fee) return;
  openAmountModal({
    billId: bill.BillID,
    title: "Edit Professional Fee",
    saveLabel: "Save",
    bodyHtml: `
      <div class="mb-2 small text-muted">${esc(fee.DoctorName)}</div>
      <div class="mb-2">
        <label class="form-label">Fee Amount (₱) <span class="text-danger">*</span></label>
        <input type="number" min="0.01" step="0.01" class="form-control" id="edit-fee-amount" value="${esc(fee.FeeAmount)}" />
      </div>
      <div class="mb-2">
        <label class="form-label">Description</label>
        <input type="text" class="form-control" id="edit-fee-desc" value="${esc(fee.Description ?? "")}" />
      </div>`,
    onSave: async () => {
      const feeAmount = document.getElementById("edit-fee-amount").value;
      if (!(parseFloat(feeAmount) > 0)) { alert("Enter a fee amount greater than 0."); return; }
      return postBilling(baseApiUrl, "updateProfessionalFee", {
        professionalFeeId: fee.ProfessionalFeeID,
        feeAmount,
        description: document.getElementById("edit-fee-desc").value.trim() || null,
      });
    },
  });
};

const showEditLabFeeModal = (bill, lab) => {
  if (!lab) return;
  openAmountModal({
    billId: bill.BillID,
    title: "Edit Laboratory Fee",
    saveLabel: "Save",
    bodyHtml: `
      <div class="mb-2 small text-muted">${esc(lab.TestName)}</div>
      <div class="mb-2">
        <label class="form-label">Amount (₱) <span class="text-danger">*</span></label>
        <input type="number" min="0" step="0.01" class="form-control" id="edit-lab-amount" value="${esc(lab.Price)}" />
        <div class="form-text">Only changes this bill. Use 0 to waive the charge. To change the standard price, edit the test on the Laboratory Tests page.</div>
      </div>`,
    onSave: async () => {
      const amount = document.getElementById("edit-lab-amount").value;
      if (amount === "" || !(parseFloat(amount) >= 0)) { alert("Enter an amount of 0 or more."); return; }
      return postBilling(baseApiUrl, "updateLabCharge", { source: lab.Source, chargeId: lab.ChargeID, amount });
    },
  });
};

const showAddLabFeeModal = async (bill) => {
  const tests = await getBilling(baseApiUrl, "getLabTestPrices");
  if (!Array.isArray(tests)) { checkBillingResult(tests); return; }
  const options = tests
    .map((t) => `<option value="${t.TestID}" data-price="${esc(t.Price)}">${esc(t.TestName)} — ${peso(t.Price)}</option>`)
    .join("");

  openAmountModal({
    billId: bill.BillID,
    title: "Add Laboratory Fee",
    saveLabel: "Add Lab Fee",
    bodyHtml: `
      <div class="mb-2">
        <label class="form-label">Laboratory test</label>
        <select class="form-select" id="lab-fee-test">
          <option value="">— Other (type a name below) —</option>
          ${options}
        </select>
      </div>
      <div class="mb-2">
        <label class="form-label">Description <span class="text-danger" id="lab-fee-desc-star">*</span></label>
        <input type="text" maxlength="150" class="form-control" id="lab-fee-desc" placeholder="e.g. Ultrasound" />
      </div>
      <div class="mb-2">
        <label class="form-label">Amount (₱) <span class="text-danger">*</span></label>
        <input type="number" min="0.01" step="0.01" class="form-control" id="lab-fee-amount" placeholder="0.00" />
        <div class="form-text">Choosing a test fills in its price list amount. You can change it for this bill.</div>
      </div>`,
    onSave: async () => {
      const testId = document.getElementById("lab-fee-test").value;
      const description = document.getElementById("lab-fee-desc").value.trim();
      const amount = document.getElementById("lab-fee-amount").value;
      if (!testId && !description) { alert("Pick a laboratory test or type a description."); return; }
      if (!(parseFloat(amount) > 0)) { alert("Enter an amount greater than 0."); return; }
      return postBilling(baseApiUrl, "insertLabCharge", { billId: bill.BillID, testId, description, amount });
    },
  });

  document.getElementById("lab-fee-test").addEventListener("change", (e) => {
    const price = e.target.selectedOptions[0]?.dataset.price;
    if (e.target.value && price !== undefined) document.getElementById("lab-fee-amount").value = parseFloat(price) > 0 ? price : "";
    document.getElementById("lab-fee-desc-star").style.display = e.target.value ? "none" : "";
  });
};


// ── Walk-in payment: staff collect payment at the counter (Admin + Staff) ──────
const showWalkInPayModal = (bill) => {
  const total = parseFloat(bill.TotalAmount) || 0;
  document.getElementById("fee-modal-title").textContent = "Collect Walk-in Payment";
  document.getElementById("fee-modal-body").innerHTML = `
    <div class="mb-3">
      <div class="small text-muted">${esc(bill.PatientName)} · Dr. ${esc(bill.DoctorName)} · ${esc(bill.AppointmentDate)}</div>
      <div class="d-flex justify-content-between align-items-baseline">
        <span>Amount due</span><strong style="font-size:1.4rem;">${peso(total)}</strong>
      </div>
    </div>

    <div class="mb-2">
      <label class="form-label">Payment method <span class="text-danger">*</span></label>
      <select class="form-select" id="walkin-method">
        <option value="Cash" selected>Cash</option>
        <option value="Card">Card (at the counter)</option>
        <option value="GCash">GCash</option>
        <option value="Maya">Maya</option>
      </select>
    </div>

    <div id="walkin-cash-box" class="mb-2">
      <label class="form-label">Amount received (₱) <span class="text-danger">*</span></label>
      <input type="number" min="0" step="0.01" class="form-control" id="walkin-received" value="${total.toFixed(2)}" />
      <div class="form-text fw-bold" id="walkin-change"></div>
    </div>

    <div id="walkin-ref-box" class="mb-2 d-none">
      <label class="form-label">Reference / approval number <span class="text-danger">*</span></label>
      <input type="text" maxlength="40" class="form-control" id="walkin-ref" placeholder="From the receipt or terminal slip" autocomplete="off" />
    </div>

    <div class="alert alert-info small mb-0">
      Only click <strong>Confirm payment</strong> after you have received the payment. The bill will be marked
      <strong>Paid</strong> and a receipt can be printed.
    </div>`;
  document.getElementById("fee-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-confirm-walkin">Confirm payment</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>`;

  const modal = new bootstrap.Modal(document.getElementById("fee-modal"), { backdrop: "static" });
  modal.show();

  const methodSel = document.getElementById("walkin-method");
  const received = document.getElementById("walkin-received");
  const changeEl = document.getElementById("walkin-change");

  const updateChange = () => {
    const diff = Math.round(((parseFloat(received.value) || 0) - total) * 100) / 100;
    changeEl.className = "form-text fw-bold " + (diff < 0 ? "text-danger" : "text-success");
    changeEl.textContent = diff < 0 ? `Short by ${peso(-diff)}` : `Change to give: ${peso(diff)}`;
  };
  received.addEventListener("input", updateChange);
  updateChange();

  methodSel.addEventListener("change", () => {
    const cash = methodSel.value === "Cash";
    document.getElementById("walkin-cash-box").classList.toggle("d-none", !cash);
    document.getElementById("walkin-ref-box").classList.toggle("d-none", cash);
  });

  const confirmBtn = document.getElementById("btn-confirm-walkin");
  confirmBtn.addEventListener("click", async () => {
    const method = methodSel.value;
    const reference = document.getElementById("walkin-ref").value.trim();
    const amountReceived = received.value;

    if (method === "Cash") {
      if (Math.round((parseFloat(amountReceived) || 0) * 100) < Math.round(total * 100)) {
        alert("The amount received is less than the amount due."); return;
      }
    } else if (!/^[A-Za-z0-9][A-Za-z0-9 _-]{2,39}$/.test(reference)) {
      alert("Enter the reference / approval number (3-40 letters, numbers, spaces, - or _)."); return;
    }

    confirmBtn.disabled = true;   // no double clicks
    let res;
    try {
      res = await postBilling(baseApiUrl, "recordWalkInPayment", {
        billId: bill.BillID, method, reference, amountReceived: method === "Cash" ? amountReceived : null,
      });
    } catch (e) {
      confirmBtn.disabled = false;
      alert("Could not reach the server. The payment was NOT recorded. Please try again.");
      return;
    }

    if (!res?.paid) {
      confirmBtn.disabled = false;
      alert(BILLING_ERRORS[res?.error] || "ERROR");
      if (["already_paid", "not_payable"].includes(res?.error)) { modal.hide(); displayBills(); }
      return;
    }

    // Done: show the result and offer the receipt
    document.getElementById("fee-modal-title").textContent = "Payment recorded ✓";
    document.getElementById("fee-modal-body").innerHTML = `
      <div class="alert alert-success mb-3">The bill is now <strong>Paid</strong>.</div>
      <table class="table table-sm mb-0">
        <tr><td>Amount paid</td><td class="text-end"><strong>${peso(res.amount)}</strong></td></tr>
        <tr><td>Method</td><td class="text-end">${esc(res.method)} (Walk-in)</td></tr>
        <tr><td>Reference no.</td><td class="text-end">${esc(res.referenceNo)}</td></tr>
        ${method === "Cash" ? `<tr><td>Change to give</td><td class="text-end"><strong>${peso(res.change)}</strong></td></tr>` : ""}
      </table>`;
    document.getElementById("fee-modal-footer").innerHTML = `
      <a class="btn btn-primary btn-sm me-2" href="receipt.html?bill=${esc(bill.BillID)}">Print Receipt</a>
      <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>`;
    displayBills();
  });
};
