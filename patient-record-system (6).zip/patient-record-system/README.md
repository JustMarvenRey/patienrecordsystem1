# Patient Record System — Master Files (Milestone 1)

All five master file modules are implemented: **Patients**, **Doctors**, **Medicines**,
**Specializations**, and **Diagnoses / ICD-10**. All give the admin a CRUD screen, but Doctors is
more involved because a doctor's specializations live in a many-to-many junction — see below.
There is **no separate `DOCTOR` table**: a doctor is a `USERS` row whose role is `Doctor`.

A **Login** screen sits in front of all of that (there is no public sign-up — accounts are created by an
administrator), and a **Home** dashboard is the first thing you see after signing in — see
[Login, User Accounts & Home](#login-user-accounts--home) below.

## Setup
1. Import `database/patient_record_system.sql` into MySQL. It creates the `patient_record_system`
   database and:
   - `PATIENT` (10 sample rows: 9 Active, 1 Inactive)
   - `ROLE`, `USERS` (with `Phone`), `SPECIALIZATION`, `DOCTOR_SPECIALIZATION` (10 sample doctors:
     9 Active, 1 Inactive, one with two specializations to show the many-to-many link)
   - `MEDICINE` (10 sample rows: 9 Active, 1 Inactive)
   - `DIAGNOSIS_ICD10` (10 sample rows: 9 Active, 1 Inactive)

   **Already have a database that still has the old `DOCTOR` table?** Don't re-import — run
   `database/merge-doctor-into-users.sql` once. It copies each doctor's phone onto `USERS.Phone`,
   re-points `DOCTOR_SPECIALIZATION` from `DoctorID` to `UserID`, and drops `DOCTOR`. (Back up first.)
   A ready-made full dump with the merge already applied is also provided as
   `patient_record_system-merged.sql`.

   **Already imported this before?** `CREATE TABLE IF NOT EXISTS` skips tables that already exist,
   but the `INSERT` statements underneath will still try to run and fail with a duplicate-key
   error (e.g. `#1062 - Duplicate entry 'jramirez'`) if you re-run the same file on a database that
   already has this data. Either run `DROP DATABASE IF EXISTS patient_record_system;` first and
   then re-import the whole file, or just skip re-importing — your existing tables and rows are
   already there.
2. Edit `api/connection-pdo.php` with your MySQL credentials if they differ from the XAMPP defaults.
3. Put this whole `patient-record-system` folder inside your web server's document root
   (e.g. `htdocs/patient-record-system` for XAMPP).
4. Update `baseApiUrl` in `js/login.js`, `js/home.js`, `js/index.js`,
   `js/index-doctors.js`, `js/index-medicines.js`, `js/index-specializations.js`, and
   `js/index-diagnoses.js` if your folder path differs from
   `http://localhost/patient-record-system/api`.
5. Open `login.html` through `http://localhost/...` (not `file://`) so the AJAX calls work. Sign
   in with one of the sample accounts below and you'll land on
   `home.html`, which links out to `index.html` (Patients), `doctors.html` (Doctors),
   `medicines.html` (Medicines), `specializations.html` (Specializations), and `diagnoses.html`
   (Diagnoses / ICD-10). The nav bar on every page links between all of them, plus a Logout button.

## Login, User Accounts & Home
No new tables were added for this — it reuses the `ROLE` and `USERS` tables that already existed
for the Doctors module.

- **`login.html`** — sign-in form. Checks the username/password against `USERS` (joined to `ROLE`
  for the role name), and blocks the login if the account's `Status` is `Inactive`. On success the
  user's `UserID`, `Username`, `FirstName`, `LastName`, `RoleID`, and `RoleName` are kept in
  `sessionStorage` under `currentUser`, and the browser is sent to `home.html`.
- **`users.html`** (Admin only) — the **User Accounts** screen. There is no self-service sign up;
  an administrator creates every account here (First/Last Name, Username, Password, Role). It can
  update accounts (password is optional — blank keeps the current one), and deactivate/restore them
  (soft delete). **Phone** is a normal field for every role. **Doctor** accounts are created here
  too: picking the Doctor role reveals the Specializations checkboxes, and `insertUser` then writes
  the `USERS` row and the `DOCTOR_SPECIALIZATION` rows in one transaction. Moving an account out of
  the Doctor role clears its specializations. Safeguards: you can't deactivate yourself or change
  your own role, and usernames must be unique.
- **`home.html`** — the post-login landing page. Greets the signed-in user by name/role and shows a
  card per module (Patients, Doctors, Medicines, Specializations, Diagnoses) linking into the
  existing screens.
- **`js/auth-guard.js`** — included on `home.html` and all five master file pages. Redirects to
  `login.html` if no `currentUser` is in `sessionStorage`, and otherwise fills in the "Signed in as
  ... | Logout" control now shown on the right side of every nav bar.

### Try it right away
Two sample accounts are seeded by the SQL file:

| Username | Password | Role |
|---|---|---|
| `admin` | `admin123` | Admin |
| `frontdesk` | `staff123` | Staff |

### API operations (`api/users.php`) — Admin only
Every call sends `actingUserId` and the API checks it belongs to an active Admin. Note there are no
server-side sessions in this project, so this is a basic guard, not real authentication.

| operation | method | purpose |
|---|---|---|
| `getAllUsers` | GET | all accounts, every role (Active + Inactive) |
| `getAssignableRoles` | GET | active roles, for the role dropdown |
| `getUser` | GET | single account by `userId` |
| `insertUser` | POST | create an account |
| `updateUser` | POST | edit an account (password only changed if provided) |
| `deleteUser` | GET | soft delete (`Status = 'Inactive'`) |
| `restoreUser` | GET | undo a soft delete |

### API operations (`api/auth.php`)
| operation | method | purpose |
|---|---|---|
| `login` | POST | checks credentials, returns the user (minus password) or an error |

**Note:** exactly like the rest of this project, `Password` is compared/stored as plain text to
match the class's teaching pattern — in a real system you'd use `password_hash()` /
`password_verify()`.

## Appearance (theme picker)
Every page — including the login screen — has a **🎨** button (top bar; top-right corner on the login page).
It opens a small panel with:

- **Mode:** Light / Auto (follows the device's light-dark setting) / Dark
- **Accent color:** Green (default), Blue, Teal, Purple, Slate — recolors the top bar, sidebar highlights,
  table headers, links / focus rings, login screen and dashboard charts
- **Text size:** Normal / Large
- **Reset to default**

The choice is saved in that browser (`localStorage`, key `prs-theme`) — no database change, and each person
on each computer keeps their own. Files: `js/theme.js` (loaded in `<head>` of every page so the saved theme
is applied before the page paints) and the "Theming" section at the end of `css/style.css`.

- **Status colors never change with the accent:** Paid / Completed = green, Pending / waiting = amber,
  Cancelled / No-Show / errors = red. Bootstrap action buttons (Add, Delete, Restore…) keep their colors too.
- **Adding a new page?** Put `<script src="./js/theme.js"></script>` in `<head>` and use the CSS variables
  (`var(--card-bg)`, `var(--text-main)`, `var(--prs-green-text)`, …) instead of hard-coded colors like `#fff`
  or `#006400`, otherwise that part of the page won't follow the theme.
- **Adding an accent color:** add one `:root[data-accent="name"]` block and one dark-mode block in
  `style.css`, plus an entry in `ACCENTS` in `js/theme.js`.

## Dashboard Analytics (per role)
`home.html` shows an **Analytics** section whose content depends on who is signed in. It is read-only —
no new tables or columns. Use the range selector (3 / 6 / 12 months / all time) and **Refresh**.

| Role | Sees | Charts |
|---|---|---|
| **Admin** | Clinic-wide overview: active patients, appointments, consultations, revenue collected + pending | Appointments by month, status mix, revenue by month, patients by gender / age, top diagnoses, most prescribed medicines, doctor workload |
| **Doctor** | Only **their own** records: appointments today, awaiting consultation, consultations, patients seen | My appointments by month, status mix, diagnoses I record most, medicines I prescribe most, busiest weekdays, my patients by age |
| **Staff** | Front desk + billing: appointments today, consultations still to bill, unpaid bills, amount collected | Appointments by month, status mix, collections by month, bills by status, busiest weekdays, unpaid bills by age, appointments per doctor |

- Files: `api/analytics.php` (operation `getDashboardAnalytics`), `js/home-analytics.js`, Chart.js from the CDN in `home.html`.
- The API looks up the caller's role from `actingUserId` and returns only that role's data. A Doctor's
  numbers are always filtered to the caller's own `UserID` on the server — the browser can't request another
  doctor's data. (As elsewhere in this project there are no server-side sessions, so this is a basic guard.)
- Counts use only Active consultations / prescriptions / diagnoses. Bills are revenue when `Paid`, pending
  when `Pending`; `Cancelled` bills are ignored in money totals. "Awaiting consultation" = appointments still
  `Scheduled` whose date is today or earlier (creating a consultation marks the appointment `Completed`).

## Patients — what's included
- **Create**: form at the top of the page → "Add Patient".
- **Read**: table lists all patients; toggle "Show inactive patients" to include deactivated ones.
- **Update**: "Update" button opens a modal with an editable form.
- **Delete (soft)**: "Delete" button deactivates the patient (`Status = 'Inactive'`) instead of
  removing the row. A "Restore" button reactivates them.

### Hard delete vs. soft delete — why Patients uses soft delete
Patients are referenced by `APPOINTMENT`, `CONSULTATION`, and `BILLING`. Physically deleting a
patient row would break or orphan every appointment/consultation/bill tied to that `PatientID`,
destroying medical and billing history. So `PATIENT` has a `Status` column (`Active` / `Inactive`);
"deleting" a patient just flips it, which hides them from `getActivePatients` (what transaction
modules should call) while `getAllPatients` (the admin view) still shows them for review/restore.

### API operations (`api/patients.php`)
| operation | method | purpose |
|---|---|---|
| `getAllPatients` | GET | all patients, for the admin master file table |
| `getActivePatients` | GET | active-only patients, for transaction modules to reference |
| `getPatient` | GET | single patient by `patientId` |
| `insertPatient` | POST | create a new patient |
| `updatePatient` | POST | edit an existing patient |
| `deletePatient` | GET | soft delete (sets `Status = 'Inactive'`) |
| `restorePatient` | GET | undo a soft delete (`Status = 'Active'`) |

## Doctors — what's included

### Doctors are just users (no DOCTOR table)
Per the revised ERD, a doctor is a **USERS** row (`Username`, `Password`, `FirstName`, `LastName`,
`Phone`, `Status`, `RoleID`) whose role is `Doctor`; their ID is their `UserID`. Specializations are
a separate lookup table (`SPECIALIZATION`), connected through a many-to-many junction
(`DOCTOR_SPECIALIZATION(UserID, SpecializationID)`), since one doctor can have more than one
specialization. The Doctors screen is simply a doctor-focused view of the users with the Doctor role:

```
ROLE  <---  USERS  --- M:N (via DOCTOR_SPECIALIZATION) ---  SPECIALIZATION
```

- **Create**: there is no Add form on the Doctors page. Doctors are created from **User Accounts**
  by choosing the Doctor role (see above); they then show up here automatically.
- **Read**: table lists all doctors (name, username, phone, a comma-joined list of specialization
  names via `GROUP_CONCAT`, status); toggle "Show inactive doctors" to include deactivated ones.
- **Update**: modal re-populates the specialization multi-select with the doctor's current picks.
  Password field is optional — leave it blank to keep the current password; the API only updates
  it if a new value was sent.
- **Delete (soft)**: deactivates the linked `USERS` row (`Status = 'Inactive'`) — see reasoning
  below. A "Restore" button reactivates it.
- `api/specializations.php` exposes a read-only `getSpecializations` operation just to populate
  the multi-select — the same technique as `courses.php` populating the `<select id="course">` in
  the reference lecture material.

**Note:** `Password` is stored as plain text here to match the class's teaching pattern
(`students.php` does the same). In a real system you'd hash it (e.g. `password_hash()` /
`password_verify()` in PHP) before it ever reaches the database.

### Hard delete vs. soft delete — why Doctors uses soft delete
Doctors are referenced by `APPOINTMENT` and, through `CONSULTATION`, by `PROFESSIONAL_FEE`.
Physically deleting a doctor's account would break or orphan those records. So `USERS.Status`
(`Active` / `Inactive`) is the soft-delete flag for every account, doctors included: "deleting" a
doctor flips their linked `USERS` row to `Inactive`, hiding them from `getActiveDoctors` (what
Appointments/Consultations should call) while `getAllDoctors` (the admin view) still shows them
for review/restore, and every past appointment/consultation/fee tied to that `UserID` stays valid.

### API operations (`api/doctors.php`)
| operation | method | purpose |
|---|---|---|
| `getAllDoctors` | GET | all doctors + specialization list, for the admin master file table |
| `getActiveDoctors` | GET | active-only doctors, for transaction modules to reference |
| `getDoctor` | GET | single doctor by `userId`, plus their specialization IDs/names |
| `updateDoctor` | POST | updates the USERS row (incl. Phone), replaces the specialization set |
| `deleteDoctor` | GET | soft delete (sets the linked USERS row to `Status = 'Inactive'`) |
| `restoreDoctor` | GET | undo a soft delete (`Status = 'Active'`) |

### API operations (`api/specializations.php`)
| operation | method | purpose |
|---|---|---|
| `getSpecializations` | GET | lookup list, used to populate the specialization checkboxes |

## Medicines — what's included
`MEDICINE` (`MedicineID`, `MedicineName`, `Description`, `DosageForm`) is a simple lookup table,
same shape as `PATIENT`. The ERD doesn't show a `Status` column on it, but since it's referenced
by `PRESCRIPTION` (a transaction table), the same soft-delete pattern used for `PATIENT` is
applied here too — a `Status` column was added.

- **Create**: form → "Add Medicine" (Name, Dosage Form dropdown, Description).
- **Read**: table lists all medicines; toggle "Show inactive medicines" to include deactivated ones.
- **Update**: "Update" button opens a modal with an editable form.
- **Delete (soft)**: "Delete" button deactivates the medicine (`Status = 'Inactive'`) instead of
  removing the row, so historical prescriptions that reference it stay valid. "Restore" undoes it.

### API operations (`api/medicines.php`)
| operation | method | purpose |
|---|---|---|
| `getAllMedicines` | GET | all medicines, for the admin master file table |
| `getActiveMedicines` | GET | active-only medicines, for the Prescription module to reference |
| `getMedicine` | GET | single medicine by `medicineId` |
| `insertMedicine` | POST | create a new medicine |
| `updateMedicine` | POST | edit an existing medicine |
| `deleteMedicine` | GET | soft delete (sets `Status = 'Inactive'`) |
| `restoreMedicine` | GET | undo a soft delete (`Status = 'Active'`) |

## Specializations — what's included
`SPECIALIZATION` (`SpecializationID`, `SpecializationName`, `Description`) is the same lookup
table that already powered the multi-select on the Doctors page (`api/specializations.php`'s
`getSpecializations`). This module turns it into its own manageable master file with a full CRUD
screen, rather than just a dropdown source.

- **Create**: form → "Add Specialization" (Name, Description).
- **Read**: table lists all specializations, plus a "Doctors" column showing how many doctors
  currently have each one assigned (via `DOCTOR_SPECIALIZATION`).
- **Update**: "Update" button opens a modal with an editable form.
- **Deactivate (soft delete)**: "Deactivate" marks the row `Inactive` (nothing is removed), like the other
  master files. A "Show inactive specializations" checkbox reveals deactivated rows, which get a **Restore**
  button. Doctors who already have a deactivated specialization keep it; it just stops being offered when a
  specialization is picked for a doctor.

### Hard delete vs. soft delete — why Specializations uses soft delete
A specialization is linked to doctors through the `DOCTOR_SPECIALIZATION` junction table. Deactivating it
(instead of deleting the row) keeps those links intact and lets an admin bring it back with one click.
`SPECIALIZATION.Status` (`'Active'` | `'Inactive'`) is added automatically to an older database the first time
any API is called (`api/auto-migrate.php`); `database/specialization-soft-delete.sql` does the same by hand.

### API operations (`api/specializations.php`)
| operation | method | purpose |
|---|---|---|
| `getSpecializations` | GET | lookup list incl. `Status` — used by the doctor/user forms (they offer Active ones only) |
| `getAllSpecializations` | GET | all specializations + doctor count, for the admin master file table |
| `getSpecialization` | GET | single specialization by `specializationId` |
| `insertSpecialization` | POST | create a new specialization |
| `updateSpecialization` | POST | edit an existing specialization |
| `deleteSpecialization` | GET | soft delete — sets `Status = 'Inactive'` |
| `restoreSpecialization` | GET | undo a soft delete — sets `Status = 'Active'` |

## Diagnoses / ICD-10 — what's included
`DIAGNOSIS_ICD10` (`DiagnosisID`, `ICD10Code`, `DiagnosisName`, `Description`) is a simple lookup
table, same shape as `MEDICINE`. It will be referenced by `CONSULTATION_DIAGNOSIS` once the
Consultation transaction module exists.

- **Create**: form → "Add Diagnosis" (ICD-10 Code, Diagnosis Name, Description). `ICD10Code` is
  `UNIQUE` at the database level, so duplicates are rejected.
- **Read**: table lists all diagnoses; toggle "Show inactive diagnoses" to include deactivated ones.
- **Update**: "Update" button opens a modal with an editable form.
- **Delete (soft)**: "Delete" button deactivates the diagnosis (`Status = 'Inactive'`) instead of
  removing the row. "Restore" undoes it.

### Hard delete vs. soft delete — why Diagnoses uses soft delete
This is the opposite call from Specializations, and on purpose. `DIAGNOSIS_ICD10` will be
referenced by `CONSULTATION_DIAGNOSIS`, which records what a doctor *actually diagnosed a patient
with* during a real consultation — that's clinical history, not just a current
capability/assignment the way a doctor's specialization is. Hard-deleting a diagnosis code could
orphan or invalidate a real medical record, so the same soft-delete pattern used for
`PATIENT`/`MEDICINE` is used here: a `Status` column, `deleteDiagnosis` flips it to `'Inactive'`,
and `getActiveDiagnoses` is what the Consultation module should call so retired codes don't show
up as new-diagnosis options while old consultations that used them stay valid.

### API operations (`api/diagnoses.php`)
| operation | method | purpose |
|---|---|---|
| `getAllDiagnoses` | GET | all diagnoses, for the admin master file table |
| `getActiveDiagnoses` | GET | active-only diagnoses, for the Consultation module to reference |
| `getDiagnosis` | GET | single diagnosis by `diagnosisId` |
| `insertDiagnosis` | POST | create a new diagnosis |
| `updateDiagnosis` | POST | edit an existing diagnosis |
| `deleteDiagnosis` | GET | soft delete (sets `Status = 'Inactive'`) |
| `restoreDiagnosis` | GET | undo a soft delete (`Status = 'Active'`) |

## File map
| Patients | Doctors | Medicines | Specializations | Diagnoses / ICD-10 |
|---|---|---|---|---|
| `index.html` | `doctors.html` | `medicines.html` | `specializations.html` | `diagnoses.html` |
| `js/index.js` | `js/index-doctors.js` | `js/index-medicines.js` | `js/index-specializations.js` | `js/index-diagnoses.js` |
| `js/modules/view.js` `update.js` `delete.js` | `js/modules-doctors/view.js` `update.js` `delete.js` | `js/modules-medicines/view.js` `update.js` `delete.js` | `js/modules-specializations/view.js` `update.js` `delete.js` | `js/modules-diagnoses/view.js` `update.js` `delete.js` |
| `api/patients.php` | `api/doctors.php` | `api/medicines.php` | `api/specializations.php` | `api/diagnoses.php` |
| `PATIENT` table | `ROLE`, `USERS`, `DOCTOR`, `DOCTOR_SPECIALIZATION` tables | `MEDICINE` table | `SPECIALIZATION` table | `DIAGNOSIS_ICD10` table |

## Delete strategy summary
| Table | Strategy | Why |
|---|---|---|
| `PATIENT` | Soft delete | Referenced by Appointment, Consultation, Billing (real clinical/billing history) |
| `USERS` (Doctors) | Soft delete | Referenced by Appointment, and via Consultation by Professional Fee |
| `MEDICINE` | Soft delete | Referenced by Prescription (real clinical history) |
| `SPECIALIZATION` | Soft delete | Linked to doctors through a junction table; deactivating keeps those links and can be restored |
| `DIAGNOSIS_ICD10` | Soft delete | Will be referenced by Consultation_Diagnosis (real clinical history) |

## Next modules
All planned Milestone 1 master files (Patients, Doctors, Medicines, Specializations,
Diagnoses / ICD-10) are done. Next up would be the transaction modules (Appointments,
Consultations, Billing, Prescriptions) that reference these lookup tables.

## Changes: Diagnoses → Doctor, vitals & labs flow
- **Diagnoses / ICD-10 master file moved from Admin to Doctor.** Doctors get full CRUD on `diagnoses.html`
  (sidebar link + Home card). Admin no longer sees the page, the sidebar link, the Home card, or the
  Diagnoses section on `consultation-detail.html`. Change is in `js/auth-guard.js` and `js/home.js`.
- **Vital signs right after a consultation.** Saving a *new* consultation now opens
  `consultation-detail.html?id=<id>&new=1`, which automatically opens the Record Vital Signs form.
  `api/consultations.php` `insertConsultation` now returns `{"success":1,"consultationId":N}` instead of `1`.
- **Laboratory only if needed.** After vital signs are first saved, the doctor is asked whether a lab test
  is needed (OK opens the Add Laboratory Test form; Cancel skips it). The Laboratory section stays available
  on the page for later.

---

## Billing & Professional Fees

| Role | Billing page | Bills (create / edit / mark Paid or Cancelled) | Professional fees (add / remove) |
|---|---|---|---|
| Admin | yes | yes | yes (any amount, per bill) |
| Staff | yes | yes | add / remove at the Admin-set fee only |
| Doctor | no (sees the bill read-only on the consultation page) | no | view only |

- **Billing page** (`billing.html`): lists every bill with a status filter, **+ Create Bill** (picks from
  consultations that don't have a bill yet), **View** (bill details + fees + fees subtotal) and **Edit**
  (date, total, status).
- The consultation detail page shows the same bill/fee controls for the same roles.
- `api/billing.php` enforces the split using `actingUserId` (sent by the client, same approach as
  `users.php` — there are no server-side sessions, so this is a guard against casual misuse, not real
  authentication). It also validates dates, statuses and amounts (totals can't be negative, fees must be > 0).

| operation | method | who |
|---|---|---|
| `getAllBills` | GET | Admin, Staff |
| `getUnbilledConsultations` | GET | Admin, Staff |
| `getBillingByConsultation`, `getProfessionalFees`, `getActiveDoctors` | GET | anyone (read) |
| `insertBilling`, `updateBilling` | POST | Admin, Staff |
| `insertProfessionalFee`, `removeProfessionalFee` | POST | Admin only |

## Same-time appointments and the queue
Many patients can book the **same doctor at the same date and time**. They are put in a queue by who **submitted
first**, so patients are consulted first come, first served.

- Each appointment shows a **QUEUE** number (#1, #2, ...) on Appointments (Admin / Staff / Doctor) and on **My Appointments** (Patient).
  #1 is the patient who requested that doctor and time first (`CreatedAt`, then the appointment number if two came in the same second).
- The queue is per **doctor + date + time**, and it is calculated when the list loads (`$queueSql` in `api/appointments.php`),
  not stored. If someone cancels, the patients behind them move up automatically. Cancelled appointments have no number.
- In the Appointments list, same-time appointments are shown in queue order (the **Next up** sort puts #1 first).
- The only booking guard left: the same **patient** can't have two scheduled appointments at the same date and time.
- No database change is needed. (The unused `APPOINTMENT.QueueNumber` / `CalledAt` columns in some databases are not used.)

## Updating the app (browser cache)
The pages load their scripts with `?v=<number>` (e.g. `index-specializations.js?v=20261022`), and the JS modules
import each other the same way. If you change a JS file and the browser still shows the old behaviour, bump that
number everywhere (search & replace `20261022`) or hard-refresh with Ctrl+F5.

## Patient logins (view own medical records)
A fourth role, **Patient**, lets a patient sign in and see **only their own** medical records
(consultations, vitals, diagnoses, lab results, prescriptions) — read-only, no other module.

- The **Patient** role and a new `USERS.PatientID` column are created automatically the first time the
  API connects (`api/auto-migrate.php`). `database/add-patient-role.sql` does the same by hand if you prefer.
- In **User Accounts** (Admin), pick the **Patient** role, then choose the patient record the login belongs to.
  Only Active patients who don't have a login yet are listed (one login per patient).
- A Patient login lands on the Dashboard with one card, **My Medical Records**. `medical-history.js` pins the
  page to the account's own `PatientID`, and `api/patients.php` refuses any other patient for a Patient account.
- A Patient account whose linked patient is Inactive can't sign in.
- **My Appointments** (`my-appointments.html`): the patient books a visit online (doctor, date, time, reason) and
  can cancel their own future Scheduled appointments. It goes through the same validation and same-patient guard
  as staff booking; the patient is always taken from the login, never from the request.
- **My Bills** (`my-bills.html`): the patient sees only the bills of their own consultations (with professional-fee
  lines) and can **Pay Online** a Pending bill. The server charges the bill's own `TotalAmount`, writes a `PAYMENT` row
  (method + reference number) and sets the bill to Paid in one transaction, so a double-click can't pay twice.
  **This is a demo checkout - no real money moves and no card details are collected or stored.** To go live, charge
  through a gateway (e.g. PayMongo, GCash, Maya, Stripe) at the marked spot in `payMyBill()` in `api/billing.php`
  and only continue once the gateway confirms.
- Like the rest of this app there are no server-side sessions (the client sends `actingUserId`), so this is a
  guard, not hardened authentication. Real protection would need PHP sessions/tokens and `password_hash()`.


## Billing: professional fees + laboratory charges
A bill's total is **calculated automatically** and can no longer be typed in:

    total = active professional fees on the bill
          + price of every active laboratory test recorded for the bill's consultation

- **Laboratory Tests** each have a **Price** (set by the Admin on the Fee Schedule tab). A lab record keeps a copy of the
  price from the moment it was ordered, so changing the price list later does not change old bills.
- Creating a bill only asks for the consultation and bill date. Adding or removing a professional fee,
  or ordering / changing / removing a lab test, updates the total of that consultation's bill.
- Only a **Pending** bill is recalculated. A **Paid** or **Cancelled** bill is final, and its fees can't be
  changed (restore / set it back to Pending first). A lab test ordered after a bill is paid is not added.
- Bills created before this change keep their old typed totals until a fee or lab test on them changes.
- The new `Price` columns are added automatically by `api/auto-migrate.php`; `database/add-billing-charges.sql`
  is the manual equivalent. New API operation: `getLabCharges` (`api/billing.php`).

### Admin: managing amounts on a bill
On a **Pending** bill (Billing page → View), an **Admin** can:
- **Edit** the amount / description of a professional fee, and add or remove fees;
- **Edit** the amount of a laboratory charge (use 0 to waive it) for that bill only;
- **+ Add Lab Fee** (pick a test from the price list or type a name, with its amount), and remove fees they added.

Staff can still add and remove professional fees but cannot change amounts or lab fees. Every change updates the bill
total automatically, and Paid / Cancelled bills are locked. Lab fees added by an Admin are stored in `BILL_LAB_CHARGE`.

## Fee Schedule (Admin sets the amounts)
The **Admin** decides how much things cost; Staff just apply those amounts to bills.

- **Fee Schedule** tab on the **Billing** page (Admin only; Staff don't see it): one table of every doctor's
  **professional fee** and one table of every **laboratory test price**. Change an amount and press **Save**.
  Use 0 for "no standard fee".
- **Creating a bill** automatically adds the consulting doctor's professional fee (if one is set) and the
  laboratory tests recorded for the consultation, at their price. The total is calculated from those.
- **Staff** can still create bills and add a professional fee, but the amount is always the doctor's set fee -
  they can't type their own (enforced in `api/billing.php`, not just hidden in the screen). If the doctor has
  no fee set, they're told to ask the Admin.
- **Admin** can still change the amount of a single bill from Billing -> View (edit a fee, edit/waive a lab
  charge, add a lab fee) while it is Pending; that only affects that bill.
- **Lab test prices** are set only on the Fee Schedule tab. The Laboratory Tests master file no longer shows or
  asks for a price; a newly added test starts at 0 until the Admin sets its price there.
- Changing a price affects **new** bills / newly ordered tests only. Existing bills and recorded lab tests keep
  the amount they had.
- New column `USERS.ProfessionalFee` is added automatically by `api/auto-migrate.php`;
  `database/add-fee-schedule.sql` is the manual equivalent. New API operations (Admin only):
  `getFeeSchedule`, `updateDoctorFee`, `updateLabTestPrice`.
- Doctors with a fee of 0 get no automatic fee line - set their fee first, then create the bill.

## Receipts
Every **Paid** bill has a built-in, printable **Official Receipt** (`receipt.html?bill=<BillID>`):
- **Staff / Admin:** a **Receipt** button on paid bills in Billing (and on the consultation's bill panel).
- **Patients:** **View Receipt** on paid bills in My Bills, and right after paying online.
- It lists the patient, doctor, itemised professional fees and laboratory charges, the total, and the payment
  (method + reference number for online payments; "Paid at the clinic" when staff marked the bill Paid).
- **Print / Save as PDF** uses the browser's print dialog. Receipt no. is `OR-` + the bill number.
- A patient can only open receipts of their own bills (checked on the server, `getReceipt` in `api/billing.php`).
- Put your clinic's address / phone at the top of `js/receipt.js` (`CLINIC`) to print them on the receipt.
No database change is needed.

### Walk-in payments (Admin / Staff)
On the Billing page, every **Pending** bill with an amount shows a **Collect Payment** button. Pick the method:
- **Cash:** type the amount received; the screen shows the change to give (it must cover the bill).
- **Card / GCash / Maya:** enter the reference / approval number from the receipt or terminal slip (must be unique).

Confirming records the payment (channel **Walk-in**, with the staff member who received it), marks the bill
**Paid**, and offers **Print Receipt**. The receipt then shows "Received by". Nothing is charged by the system:
staff confirm only after they have actually received the money. Online payments by patients are unchanged.

## Call Next Patient (Doctor → Frontdesk, WebSocket + SweetAlert)
After a consultation, the Doctor clicks **📢 Call Next Patient** on the **Consultations** page
(`consultations.html`): the green button at the top right of the page, in the "Consultation saved" window right
after saving, or in a patient's popup for any recorded consultation. With no consultation finished yet today, it
uses the doctor's queue for today. A SweetAlert shows who is next in that doctor's queue for the day (same doctor,
same date, still *Scheduled*, ordered by time then queue number). On confirm, every signed-in **Staff** browser
gets a SweetAlert saying which patient to send in.

1. `cd ws-server && npm install && npm start` (keep it running; default `ws://localhost:8080`).
2. Staff must have any page open (the listener is loaded from `js/auth-guard.js`).
3. Different port? Change `WS_PORT` in `js/queue-socket.js` and run the server with `PORT=<n>`.

Files: `ws-server/server.js`, `js/queue-socket.js`, `getNextPatient` in `api/appointments.php`,
buttons in `js/index-consultations.js`, listener hook at the end of `js/auth-guard.js`.
